    /*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package EDT;

import Principal.FrmPrincipal;
import static Principal.FrmPrincipal.listaAsis;
import static Principal.FrmPrincipal.listaEmp;
import java.util.Calendar;
import java.util.Date;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Alexis
 */
public class Asistencia {
    private int id;
    private String fecha;
    private String horaEntrada;

    public Asistencia(int id, String fecha, String horaEntrada) {
        this.id = id;
        this.fecha = fecha;
        this.horaEntrada = horaEntrada;
    }
//GETTER AND SETTER 
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    public String getHoraEntrada() {
        return horaEntrada;
    }

    public void setHoraEntrada(String horaEntrada) {
        this.horaEntrada = horaEntrada;
    }

    @Override
    public String toString() {
        return "Asistencia{" + "id=" + id + ", fecha=" + fecha + ", horaEntrada=" + horaEntrada + '}';
    }

    public void mostrar(){
        System.out.println(toString());
    }
    
    
    public static void marcarAsistencia(int idx, Date fechax, String hrax, JTable tablaAsis){
        if(fechax == null || hrax == null){
            JOptionPane.showMessageDialog(null, "La fecha o la hora es nula");
            return;
        }
        int ide = idx;
        String hora = hrax;
        Calendar cale = Calendar.getInstance();
        cale.setTime(fechax);
        int dia = cale.get(Calendar.DAY_OF_MONTH);
        int mes = cale.get(Calendar.MONTH) + 1;
        int anio = cale.get(Calendar.YEAR);
        
        Asistencia marcaAsis = new Asistencia(ide, dia + "/" + mes + "/" + anio, hora);
        
        FrmPrincipal.listaAsis.adiFinal(marcaAsis);
        NodoEmp R = listaEmp.getP();
        boolean idEncontrado = false;
        
        while(R != null){
            if(R.getQ().getId() == ide){
                DefaultTableModel model = (DefaultTableModel) tablaAsis.getModel();
                Object[] rowData = {marcaAsis.getId(), marcaAsis.getFecha(), marcaAsis.getHoraEntrada()};
                model.addRow(rowData);
                idEncontrado = true;
                break;
                
            }
            R = R.getSig();
        }
        if(idEncontrado){
            JOptionPane.showMessageDialog(null, "Asistencia marcada correctamente.", "Información", JOptionPane.INFORMATION_MESSAGE);
            //JOptionPane.showMessageDialog(null, "Asistencia marcada correctamente ");
        }
        else{
            JOptionPane.showMessageDialog(null, "No se encontro el ID ingresado.", "Error", JOptionPane.ERROR_MESSAGE);
            //JOptionPane.showMessageDialog(null, "No se encontro el ID ingresado");
        }
    }
    
    
    public static void eliminarAsistencia(int idx, Date fcha, JTable tablaA){
        Calendar cale = Calendar.getInstance();
        cale.setTime(fcha);
        int dia = cale.get(Calendar.DAY_OF_MONTH);
        int mes = cale.get(Calendar.MONTH) + 1;
        int anio = cale.get(Calendar.YEAR);
        String diax = String.valueOf(dia);
        String mesx = String.valueOf(mes);
        String aniox = String.valueOf(anio);
        String fechax = diax + "/" + mesx + "/" + aniox;
        
        NodoAsis R = listaAsis.getP();
        boolean sw = false;
        while(R != null){
            if (idx == R.getA().getId() && fechax.equals(R.getA().getFecha())){
                if(R == listaAsis.getP()){
                    listaAsis.setP(R.getSig());
                    sw = true;
                    JOptionPane.showMessageDialog(null, "Asistencia eliminada correctamente.", "Información", JOptionPane.INFORMATION_MESSAGE);
                    //JOptionPane.showMessageDialog(null, "Asistencia eliminada correctamente ");
                }else if(R.getSig() == null){
                    NodoAsis S = listaAsis.getP();
                    while(S.getSig() != R){
                        S = S.getSig();
                    }
                    S.setSig(null);
                    sw = true;
                    JOptionPane.showMessageDialog(null, "Asistencia eliminada correctamente.", "Información", JOptionPane.INFORMATION_MESSAGE);
                    //JOptionPane.showMessageDialog(null, "Asistencia eliminada correctamente ");
                }else{
                    NodoAsis S = listaAsis.getP();
                    while(S.getSig() != R){
                        S = S.getSig();
                    }
                    R = R.getSig();
                    S.setSig(R);
                    sw = true;
                    JOptionPane.showMessageDialog(null, "Asistencia eliminada correctamente.", "Información", JOptionPane.INFORMATION_MESSAGE);
                    //JOptionPane.showMessageDialog(null, "Asistencia eliminada correctamente ");
                }
            }
             R = R.getSig();
        }
        if(!sw)
            JOptionPane.showMessageDialog(null, "No se encontro el ID ingresado o la fecha de asistencia.", "Error", JOptionPane.ERROR_MESSAGE);
            //JOptionPane.showMessageDialog(null, "No se encontro el ID ingresado o la fecha de asistencia");
    }
    
    public static void consultarAsis(Date fechax, int idx){
        Calendar cale = Calendar.getInstance();
        cale.setTime(fechax);
        int dia = cale.get(Calendar.DAY_OF_MONTH);
        int mes = cale.get(Calendar.MONTH) + 1;
        int anio = cale.get(Calendar.YEAR);
        String diax = String.valueOf(dia);
        String mesx = String.valueOf(mes);
        String aniox = String.valueOf(anio);
        String fecha = diax + "/" + mesx + "/" + aniox;
        
        NodoAsis R = listaAsis.getP();
        while(R != null){    
            if(idx == R.getA().getId() && R.getA().getFecha().equals(fecha)){
                JOptionPane.showMessageDialog(null, "             El empleado con ID '" + idx + "'\ntiene asistencias en la fecha " + fecha, "Información", JOptionPane.INFORMATION_MESSAGE);
                return;
            }
            R = R.getSig();
        }
        JOptionPane.showMessageDialog(null, "No se encontro el ID ingresado.", "Error", JOptionPane.ERROR_MESSAGE);
        //JOptionPane.showMessageDialog(null, "No se encontro el ID ingresado");
    }
}
