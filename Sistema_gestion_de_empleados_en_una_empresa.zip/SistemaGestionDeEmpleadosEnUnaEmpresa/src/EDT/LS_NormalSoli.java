    /*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package EDT;

/**
 *
 * @author Alexis
 */
public class LS_NormalSoli extends ListaSimpleSoli{
    
    public LS_NormalSoli(){
        super();
    }
    
    public boolean esVacia() {
	if(P == null)
            return true;
	return false;
    }
    public void adiPrincipio(Solicitud x) {
	NodoSoli nuevo = new NodoSoli();
	nuevo.setZ(x);
	nuevo.setSig(P);		
	P = nuevo;			//P apunta a nuevo
    }
    public void adiFinal(Solicitud x) {
	NodoSoli nuevo = new NodoSoli();
	nuevo.setZ(x);
	if(esVacia())
            P = nuevo;		//P apunta a nuevo
	else {
            NodoSoli R = P;
            while(R.getSig() != null) {
                R = R.getSig();
            }
            R.setSig(nuevo); 
	}	
    }

    public void mostrar() {
	NodoSoli R = P;		//R apunta a la raiz P
	while(R != null) {
            R.getZ().mostrar();
            R = R.getSig();
	}
    }
    public int nroNodos() {
	NodoSoli R = P;
	int c = 0;
	if(this.esVacia())
            return 0;
	while(R != null) {
            c++;
            R = R.getSig();
	}
	return c;
    }
	
    public NodoSoli eliPrincipio(){
        NodoSoli x = new NodoSoli();
        if(!esVacia()){
            x = P;
            P = P.getSig();
            x.setSig(null);
        }
        return x;
    }
    
    public NodoSoli eliFinal(){
        NodoSoli x = new NodoSoli();
        if(!esVacia()){
            if(nroNodos() == 1){
                x = P;
                P = null;
            }else{
                NodoSoli R = P;
                NodoSoli S = P;
                while(R.getSig() != null){
                    S = R;
                    R = R.getSig();
                }
                S.setSig(null);
                x = R;
            }
        }
        return x;
    }
}
