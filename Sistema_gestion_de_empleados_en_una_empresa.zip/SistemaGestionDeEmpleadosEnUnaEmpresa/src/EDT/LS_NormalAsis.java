/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package EDT;

public class LS_NormalAsis extends ListaSimpleAsis{
    
    public LS_NormalAsis(){
        super();
    }
    
    public boolean esVacia() {
	if(P == null)
            return true;
	return false;
    }
    public void adiPrincipio(Asistencia x) {
	NodoAsis nuevo = new NodoAsis();
	nuevo.setA(x);
	nuevo.setSig(P);		
	P = nuevo;			//P apunta a nuevo
    }
    public void adiFinal(Asistencia x) {
	NodoAsis nuevo = new NodoAsis();
	nuevo.setA(x);
	if(esVacia())
            P = nuevo;		//P apunta a nuevo
	else {
            NodoAsis R = P;
            while(R.getSig() != null) {
                R = R.getSig();
            }
            R.setSig(nuevo); 
	}	
    }

    public void mostrar() {
	NodoAsis R = P;		//R apunta a la raiz P
	while(R != null) {
            R.getA().mostrar();
            R = R.getSig();
	}
    }
    public int nroNodos() {
	NodoAsis R = P;
	int c = 0;
	if(this.esVacia())
            return 0;
	while(R != null) {
            c++;
            R = R.getSig();
	}
	return c;
    }
	
    public NodoAsis eliPrincipio(){
        NodoAsis x = new NodoAsis();
        if(!esVacia()){
            x = P;
            P = P.getSig();
            x.setSig(null);
        }
        return x;
    }
    
    public NodoAsis eliFinal(){
        NodoAsis x = new NodoAsis();
        if(!esVacia()){
            if(nroNodos() == 1){
                x = P;
                P = null;
            }else{
                NodoAsis R = P;
                NodoAsis S = P;
                while(R.getSig() != null){
                    S = R;
                    R = R.getSig();
                }
                S.setSig(null);
                x = R;
            }
        }
        return x;
    }
}
