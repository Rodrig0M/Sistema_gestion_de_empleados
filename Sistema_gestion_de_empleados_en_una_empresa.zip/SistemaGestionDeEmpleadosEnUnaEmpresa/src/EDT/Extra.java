/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package EDT;

import static Principal.FrmPrincipal.listaEmp;
/**
 *
 * @author Alexis
 */
public class Extra {
    private int id;
    private int horasTrabajadas;
    private double tarifaHora;

    public Extra(int id, int horasTrabajadas, double tarifaHora) {
        this.id = id;
        this.horasTrabajadas = horasTrabajadas;
        this.tarifaHora = tarifaHora;
    }
    public Extra() {
        this.id = 0;
        this.horasTrabajadas = 0;
        this.tarifaHora = 0;
    }

    //GETTER AND SETTER
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getHorasTrabajadas() {
        return horasTrabajadas;
    }

    public void setHorasTrabajadas(int horasTrabajadas) {
        this.horasTrabajadas = horasTrabajadas;
    }

    public double getTarifaHora() {
        return tarifaHora;
    }

    public void setTarifaHora(double tarifaHora) {
        this.tarifaHora = tarifaHora;
    }
    
    public static Empleado buscarId(int idx){
        NodoEmp R= listaEmp.getP();
        while(R != null){
            if(R.getQ().getId() == idx)
                return R.getQ();
            R = R.getSig();
        }
        return null;
    }
    
    
    public static Double calcularPagoExtra(Empleado x, int horasx, double tarifa){
        if (horasx >= 0 && tarifa >= 0) {
            double pagoExtra = horasx * tarifa;
            return pagoExtra;
        } else {
            return null;
        }
    }
    
    public static Double calcularDescuento(Empleado x, int horasx, double tarifa){
        if (horasx >= 0 && tarifa >= 0) {
            double pagoExtra = horasx * tarifa;
            return pagoExtra;
        } else {
            return null;
        }
    }
}
