/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package EDT;

import static Principal.FrmPrincipal.listaEmp;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Alexis
 */
public class Beneficio {
    private int id;
    private String beneficio;

    public Beneficio(int id, String beneficio) {
        this.id = id;
        this.beneficio = beneficio;
    }

    //GETTER AND SETTER
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getBeneficio() {
        return beneficio;
    }

    public void setBeneficio(String beneficio) {
        this.beneficio = beneficio;
    }
    
    public static void agregarBeneficioEmp(int idx, String beneficio){
        NodoEmp R = listaEmp.getP();
        boolean sw = false;
        while(R != null){
            if(R.getQ().getId() == idx){
                R.getQ().setBeneficio(beneficio);
                sw = true;
            }
            R = R.getSig();
        }
        if(sw)
            JOptionPane.showMessageDialog(null, "Beneficio agregado correctamente.", "Información", JOptionPane.INFORMATION_MESSAGE);
            //JOptionPane.showMessageDialog(null,"Beneficio agregado correctamente");
        else
            JOptionPane.showMessageDialog(null, "No se encontro el ID ingresado.", "Error", JOptionPane.ERROR_MESSAGE);
            //JOptionPane.showMessageDialog(null,"No se encontro el ID ingresado");
    }
    
    
    public static void eliminarBeneficioEmp(int idx, int cix){
        NodoEmp R = listaEmp.getP();
        boolean sw = false;
        while(R != null){
            if(!R.getQ().getBeneficio().equals("Ninguno")){
                if(R.getQ().getId() == idx || R.getQ().getCi() == cix){
                    R.getQ().setBeneficio("Ninguno");
                    sw = true;
                }
            }   
            R = R.getSig();
        }
        if(sw)
            JOptionPane.showMessageDialog(null, "Beneficio eliminado correctamente.", "Información", JOptionPane.INFORMATION_MESSAGE);
            //JOptionPane.showMessageDialog(null, "Beneficio eliminado correctamente");
        else
            JOptionPane.showMessageDialog(null, "ID o CI no encontrado.", "Error", JOptionPane.ERROR_MESSAGE);
            //JOptionPane.showMessageDialog(null, "ID o Ci no encontrado"); 
    }
    
    
    public static void consultarBeneficioEmp(int idx, String benex, JTable tablaBen){
        DefaultTableModel modelo = (DefaultTableModel) tablaBen.getModel();
        modelo.setRowCount(0);
        NodoEmp R = listaEmp.getP();
        boolean sw = false;
        while(R != null){
            Empleado x = R.getQ();
            if ((x.getId() == idx) || (benex == null || benex.isEmpty() || x.getBeneficio().equals(benex))) {
            // Agregaa una fila a la tabla con los datos del empleado
            Object[] fila = {x.getId(), x.getCi(), x.getBeneficio()};
            modelo.addRow(fila);
            sw = true;
        }
            R = R.getSig();
        }
        R = listaEmp.getP();
        if(!sw)
            JOptionPane.showMessageDialog(null, "No se encontraron empleados con el Beneficio o ID.", "Error", JOptionPane.ERROR_MESSAGE);
            //JOptionPane.showMessageDialog(null, "No se encontraron empleados con el ID o el Beneficio");
    }
}
