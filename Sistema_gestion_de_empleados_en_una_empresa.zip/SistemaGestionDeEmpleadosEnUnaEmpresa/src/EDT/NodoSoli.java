/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package EDT;

/**
 *
 * @author Alexis
 */
public class NodoSoli {
    private Solicitud Z;
    private NodoSoli sig;
    
    public NodoSoli(){
        this.sig = null;
    }

    public Solicitud getZ() {
        return Z;
    }

    public void setZ(Solicitud Z) {
        this.Z = Z;
    }

    public NodoSoli getSig() {
        return sig;
    }

    public void setSig(NodoSoli sig) {
        this.sig = sig;
    }
    
}
