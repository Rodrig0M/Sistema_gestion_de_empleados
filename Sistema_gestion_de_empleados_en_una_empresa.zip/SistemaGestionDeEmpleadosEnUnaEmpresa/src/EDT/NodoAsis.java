/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package EDT;
public class NodoAsis {
    private Asistencia A;
    private NodoAsis sig;
    
    public NodoAsis(){
        this.sig = null;
    }

    public Asistencia getA() {
        return A;
    }

    public void setA(Asistencia A) {
        this.A = A;
    }

    public NodoAsis getSig() {
        return sig;
    }

    public void setSig(NodoAsis sig) {
        this.sig = sig;
    }
    
    
}
