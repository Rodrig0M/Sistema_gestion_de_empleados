/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package EDT;

/**
 *
 * @author Alexis
 */
public class LS_NormalEmp extends ListaSimpleEmp{
    public LS_NormalEmp(){
        super();
    }
    
    public boolean esVacia() {
	if(P == null)
            return true;
	return false;
    }
    public void adiPrincipio(Empleado x) {
	NodoEmp nuevo = new NodoEmp();
	nuevo.setQ(x);
	nuevo.setSig(P);		
	P = nuevo;			//P apunta a nuevo
    }
    public void adiFinal(Empleado x) {
	NodoEmp nuevo = new NodoEmp();
	nuevo.setQ(x);
	if(esVacia())
            P = nuevo;		//P apunta a nuevo
	else {
            NodoEmp R = P;
            while(R.getSig() != null) {
                R = R.getSig();
            }
            R.setSig(nuevo); 
	}	
    }

    public void mostrar() {
	NodoEmp R = P;		//R apunta a la raiz P
	while(R != null) {
            R.getQ().mostrar();
            R = R.getSig();
	}
    }
    public int nroNodos() {
	NodoEmp R = P;
	int c = 0;
	if(this.esVacia())
            return 0;
	while(R != null) {
            c++;
            R = R.getSig();
	}
	return c;
    }
	
    public NodoEmp eliPrincipio(){
        NodoEmp x = new NodoEmp();
        if(!esVacia()){
            x = P;
            P = P.getSig();
            x.setSig(null);
        }
        return x;
    }
    
    public NodoEmp eliFinal(){
        NodoEmp x = new NodoEmp();
        if(!esVacia()){
            if(nroNodos() == 1){
                x = P;
                P = null;
            }else{
                NodoEmp R = P;
                NodoEmp S = P;
                while(R.getSig() != null){
                    S = R;
                    R = R.getSig();
                }
                S.setSig(null);
                x = R;
            }
        }
        return x;
    }
}
