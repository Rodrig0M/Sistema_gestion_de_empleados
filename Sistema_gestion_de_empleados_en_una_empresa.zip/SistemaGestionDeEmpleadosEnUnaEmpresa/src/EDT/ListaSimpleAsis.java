/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package EDT;

/**
 *
 * @author Alexis
 */
public class ListaSimpleAsis {
    protected NodoAsis P;
    
    public ListaSimpleAsis(){
        this.P = null;
    }

    public NodoAsis getP() {
        return P;
    }

    public void setP(NodoAsis P) {
        this.P = P;
    }
    
}
