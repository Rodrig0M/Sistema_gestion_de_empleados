/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package EDT;

import javax.swing.JOptionPane;
import static Principal.FrmPrincipal.listaEmp;
import static Principal.FrmPrincipal.listaSoli;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Alexis
 */
public class Solicitud {
 
    private int id;
    private String tipoSoli;
    private String estado;

    public Solicitud(int id, String tipoSoli, String estado) {
        this.id = id;
        this.tipoSoli = tipoSoli;
        this.estado = estado;
    }
    
     public Solicitud() {
        this.id = 0;
        this.tipoSoli = "";
        this.estado = "";
    }

     //GETTER AND SETTER
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTipoSoli() {
        return tipoSoli;
    }

    public void setTipoSoli(String tipoSoli) {
        this.tipoSoli = tipoSoli;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    @Override
    public String toString() {
        return "Solicitud{" + "id=" + id + ", tipoSoli=" + tipoSoli + ", estado=" + estado + '}';
    }
     
    public void mostrar(){
        System.out.println(toString());
    }
    
    
    
    
    
    public static void crearSolicitud(int idx, String solix){
        NodoEmp R = listaEmp.getP();
        boolean sw = false;
        while(R != null){
            if(R.getQ().getId() == idx){
                Solicitud nuevo = new Solicitud(idx, solix, "Pendiente");
                listaSoli.adiFinal(nuevo);
                JOptionPane.showMessageDialog(null, "Solicitud creada correctamente.", "Información", JOptionPane.INFORMATION_MESSAGE);
                //JOptionPane.showMessageDialog(null, "Solicitud creada correctamente");
                sw = true;
            }
            R = R.getSig();
        }
        if(!sw)
            JOptionPane.showMessageDialog(null, "El empleado con ID " + idx + " no existe.", "Error", JOptionPane.ERROR_MESSAGE);
            //JOptionPane.showMessageDialog(null, "El empleado con ID " + idx + " no existe");
    }
    
    
    public static void administrarSolicitud(int idx, String solix, JTable tablaS){
        DefaultTableModel modelo = (DefaultTableModel) tablaS.getModel();
        modelo.setRowCount(0); // Limpiar la tabla antes de agregar las nuevas filas

        NodoSoli sol = listaSoli.getP();
        while(sol != null){
            Solicitud soliX = sol.getZ();
            NodoEmp R = listaEmp.getP();
            String nomx = "";
            String apex = "";
            boolean mostrarSolicitud = false;
            if (solix.equals("Todos") || soliX.getId() == idx || soliX.getTipoSoli().equals(solix)) {
                mostrarSolicitud = true;
            }
            if (mostrarSolicitud) {
                while (R != null) {
                    if (R.getQ().getId() == soliX.getId()) {
                        nomx = R.getQ().getNom();
                        apex = R.getQ().getApe();
                        break;
                    }
                    R = R.getSig();
                }

                Object[] row = {soliX.getId(), nomx, apex, soliX.getTipoSoli(), soliX.getEstado()};
                modelo.addRow(row);
            }   
            sol = sol.getSig();
        }
    }    
    
    
    public static void aceptarSoli(Object idx, Object solix, String estadox){
        int idAux = Integer.parseInt(idx.toString());
        String soliAux = solix.toString();
        NodoEmp R = listaEmp.getP();
        while(R != null){
            if(R.getQ().getId() == idAux){
                if(estadox.equals("Aceptada")){
                    R.getQ().setSoli(soliAux);
                }
            }    
            R = R.getSig();
        }
    }
    
    
    public static void rechazarSoli(Object idx, String estadox){
        int idAux = Integer.parseInt(idx.toString());
        NodoEmp R = listaEmp.getP();
        while(R != null){
            if(R.getQ().getId() == idAux){
                if(estadox.equals("Rechazada")){
                    R.getQ().setSoli("Ninguno");
                }
            }    
            R = R.getSig();
        }
    }
    
    public static void eliminarSoli(Object id){
        int idx = Integer.parseInt(id.toString());
        NodoSoli S;
        int nroNodos = listaSoli.nroNodos();
        for(int i = 0; i < nroNodos; i++){
            S = listaSoli.eliPrincipio();
            if(idx != S.getZ().getId())
                listaSoli.adiFinal(S.getZ());
        }
    }
}
