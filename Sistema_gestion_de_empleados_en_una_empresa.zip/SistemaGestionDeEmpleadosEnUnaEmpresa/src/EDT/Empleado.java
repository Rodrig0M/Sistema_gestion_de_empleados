/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package EDT;

import static Principal.FrmPrincipal.listaEmp;
import javax.swing.JOptionPane;
public class Empleado {
    private int id;
    private String nom;
    private String ape;
    private int ci;
    private String gen;
    private long tel;
    private String mail;
    private String puesto;
    private String beneficio;
    private String soli;
    private String turno;
    private double sueldo;

    
    //GETTER AND SETTER
    public int getId() {
        return id;
    }

    public String getNom() {
        return nom;
    }

    public String getApe() {
        return ape;
    }

    public int getCi() {
        return ci;
    }

    public String getGen() {
        return gen;
    }

    public long getTel() {
        return tel;
    }

    public String getMail() {
        return mail;
    }

    public String getPuesto() {
        return puesto;
    }

    public String getBeneficio() {
        return beneficio;
    }

    public String getSoli() {
        return soli;
    }

    public String getTurno() {
        return turno;
    }

    public double getSueldo() {
        return sueldo;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public void setApe(String ape) {
        this.ape = ape;
    }

    public void setCi(int ci) {
        this.ci = ci;
    }

    public void setGen(String gen) {
        this.gen = gen;
    }

    public void setTel(int tel) {
        this.tel = tel;
    }

    public void setMail(String mail) {
        this.mail = mail;
    }

    public void setPuesto(String puesto) {
        this.puesto = puesto;
    }

    public void setBeneficio(String beneficio) {
        this.beneficio = beneficio;
    }

    public void setSoli(String soli) {
        this.soli = soli;
    }

    public void setTurno(String turno) {
        this.turno = turno;
    }

    public void setSueldo(double sueldo) {
        this.sueldo = sueldo;
    } 

    public Empleado(int id, String nom, String ape, int ci, String gen, int tel, String mail, String puesto, String beneficio, String soli, String turno, double sueldo) {
        this.id = id;
        this.nom = nom;
        this.ape = ape;
        this.ci = ci;
        this.gen = gen;
        this.tel = tel;
        this.mail = mail;
        this.puesto = puesto;
        this.beneficio = beneficio;
        this.soli = soli;
        this.turno = turno;
        this.sueldo = sueldo;
    }
    
      public Empleado() {
        this.id = 0;
        this.nom = "";
        this.ape = "";
        this.ci = 0;
        this.gen = "";
        this.tel = 0;
        this.mail = "";
        this.puesto = "";
        this.beneficio = "";
        this.soli = "";
        this.turno = "";
        this.sueldo = 0;
    }
    
    @Override
    public String toString() {
        return "Empleado{" + "id=" + id + ", nom=" + nom + ", ape=" + ape + ", ci=" + ci + ", gen=" + gen + ", tel=" + tel + ", mail=" + mail + ", puesto=" + puesto + ", beneficio=" + beneficio + ", solicitud=" + soli + ", turno=" + turno + ", sueldo=" + sueldo + '}';
    }
    public void mostrar(){
        System.out.println(this.toString());
    }
    
    public static void agregarEmp(int idx, String nomx, String apex, int cix, String genx, int telx, String mailx, 
        String puestox, String benx, String solix, String turnox, int sueldox){
        
        
        NodoEmp R = listaEmp.getP();
        boolean sw = false;
        while(R != null){
            if(R.getQ().getId() == idx){
                JOptionPane.showMessageDialog(null, "No se puede agregar el empleado, ID existente.", 
                 "Error", JOptionPane.ERROR_MESSAGE);
                //JOptionPane.showMessageDialog(null, "No se puede agregar el empleado, ID existente");
                sw = true;
            }
            else if(R.getQ().getCi() == cix){
                JOptionPane.showMessageDialog(null, "No se puede agregar al empleado, CI existente.", 
           "Error", JOptionPane.ERROR_MESSAGE);
                //JOptionPane.showMessageDialog(null, "No se puede agregar el empleado, CI existente");
                sw = true;
            }
            R = R.getSig();
        }
        if(!sw){
            Empleado nuevo = new Empleado(idx, nomx, apex, cix, genx, telx, mailx, puestox,
    benx, solix, turnox, sueldox);
            
            listaEmp.adiFinal(nuevo);
            JOptionPane.showMessageDialog(null, "Se agrego el empleado correctamente.", 
       "Información", JOptionPane.INFORMATION_MESSAGE);
            //JOptionPane.showMessageDialog(null, "Se agrego el empleado correctamente");
        }
    }
}

