/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package EDT;


/**
 *
 * @author Alexis
 */
public class NodoEmp {
    private Empleado q;
    private NodoEmp sig;

    public NodoEmp() {
        this.sig = null;
    }

    public Empleado getQ() {
        return q;
    }

    public void setQ(Empleado q) {
        this.q = q;
    }

    public NodoEmp getSig() {
        return sig;
    }

    public void setSig(NodoEmp sig) {
        this.sig = sig;
    }

    
}
