/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package EDT;

/**
 *
 * @author Alexis
 */
public class ListaSimpleEmp {
    
    protected NodoEmp P;

    public ListaSimpleEmp() {
        this.P = null;
    }

    public NodoEmp getP() {
        return P;
    }

    public void setP(NodoEmp P) {
        this.P = P;
    }
    
    
}
