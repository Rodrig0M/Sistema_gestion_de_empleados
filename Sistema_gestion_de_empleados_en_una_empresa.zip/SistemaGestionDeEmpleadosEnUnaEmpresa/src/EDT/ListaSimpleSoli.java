/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package EDT;

/**
 *
 * @author Alexis
 */
public class ListaSimpleSoli {
    protected NodoSoli P;
    
    public ListaSimpleSoli(){
        this.P = null;
    }

    public NodoSoli getP() {
        return P;
    }

    public void setP(NodoSoli P) {
        this.P = P;
    }
    
    
}
