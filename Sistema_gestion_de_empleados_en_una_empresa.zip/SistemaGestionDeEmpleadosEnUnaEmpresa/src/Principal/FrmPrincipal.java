/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package Principal;

import EDT.Asistencia;
import EDT.Empleado;
import EDT.LS_NormalAsis;
import EDT.Solicitud;
import EDT.LS_NormalEmp;
import EDT.LS_NormalSoli;
import FrmAsistencia.ConsultarA;
import FrmAsistencia.EliminarA;
import FrmAsistencia.MarcarA;
import FrmBeneficio.AgregarB;
import FrmBeneficio.ConsultarB;
import FrmBeneficio.EliminarB;
import FrmExtra.Descuento;
import FrmExtra.PagoExtra;
import FrmRegistro.AgregarR;
import FrmRegistro.BuscarR;
import FrmRegistro.EditarR;
import FrmRegistro.EliminarR;
import FrmRegistro.RegistroR;
import FrmSolicitud.AdministrarS;
import FrmSolicitud.CrearS;
import java.awt.AlphaComposite;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.image.BufferedImage;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.SwingUtilities;

/**
 *
 * @author Alexis
 */
public class FrmPrincipal extends javax.swing.JFrame {
    //private String usuario;
    public static LS_NormalEmp listaEmp;
    public static LS_NormalAsis listaAsis;
    public static LS_NormalSoli listaSoli;
    
    
    //CONSTRUCTOR CON BIENVENIDA AL USUARIO QUE INGRESO
    //ARREGLAR BUG
    
//    public FrmPrincipal(String us){
//        usuario = us;
//        initComponents();
//        this.setLocationRelativeTo(null);
//        
//        //LISTA SIMPLE NORMAL DE EMPLEADOS
//        listaEmp = new LS_NormalEmp();
//        Empleado e1 = new Empleado(111, "Rocio", "Condori", 321, "gen", 123, "mail", "puesto", "bene", "soli", "turno", 912);
//        Empleado e2 = new Empleado(222, "Rodrigo", "Mendoza", 123, "gen", 123, "mail", "puesto", "bene", "soli", "turno", 912);
//        Empleado e3 = new Empleado(666, "Alex", "Uchasara", 123, "gen", 123, "mail", "puesto", "bene", "soli", "turno", 912);
//        listaEmp.adiFinal(e1);
//        listaEmp.adiFinal(e2);
//        listaEmp.adiFinal(e3);

    public FrmPrincipal() {
       
        initComponents();
        setIconImage(new ImageIcon(getClass().getResource("/Imagenes/VN.png")).getImage());
        
        this.setLocationRelativeTo(null);
        
        listaEmp = new LS_NormalEmp();
        Empleado e1 = new Empleado(1, "Rocio", "Quisbert", 11111, "Femenino", 75288724, "rocioQ@gmail.com", "Asesor", "Ninguno", "Ninguno", "Mañana", 2180);
        Empleado e2 = new Empleado(2, "Alexander", "Machaca", 22222, "Masculino", 69647962, "alexanderChuqui@gmail.com", "Gerente", "Ninguno", "Ninguno", "Mañana", 3000);
        Empleado e3 = new Empleado(3, "Veronica", "Apaza", 33333, "Femenino", 76491539, "veroApaza@gmail.com", "Marketing", "Ninguno", "Ninguno", "Tarde", 2570);
        Empleado e4 = new Empleado(4, "Elena", "Zapata", 44444, "Femenino", 76924776, "elenaZapata@gmail.com", "Economista", "Ninguno", "Ninguno", "Mañana", 2750);
        Empleado e5 = new Empleado(5, "Raul", "Gutierrez", 55555, "Masculino", 66120471, "raulguti@gmail.com", "Supervisor", "Ninguno", "Ninguno", "Tarde", 4320);
        listaEmp.adiFinal(e1);
        listaEmp.adiFinal(e2);
        listaEmp.adiFinal(e3);
        listaEmp.adiFinal(e4);
        listaEmp.adiFinal(e5);
        
        
        //LISTA PREDEFINIDA DE ASISTENCIAS
        listaAsis = new LS_NormalAsis();
        Asistencia a1 = new Asistencia(1, "4/12/2023", "8:30");
        Asistencia a2 = new Asistencia(2, "4/12/2023", "9:30");
        Asistencia a3 = new Asistencia(3, "4/12/2023", "10:00");
        Asistencia a4 = new Asistencia(4, "4/12/2023", "8:30");
        Asistencia a5 = new Asistencia(5, "4/12/2023", "9:30");
        Asistencia a6 = new Asistencia(1, "5/12/2023", "10:00");
        Asistencia a7 = new Asistencia(2, "5/12/2023", "11:20");
        Asistencia a8 = new Asistencia(3, "5/12/2023", "10:50");
        Asistencia a9 = new Asistencia(4, "5/12/2023", "8:30");
        Asistencia a10 = new Asistencia(5, "5/12/2023", "9:30");
        listaAsis.adiFinal(a1);
        listaAsis.adiFinal(a2);
        listaAsis.adiFinal(a3);
        listaAsis.adiFinal(a4);
        listaAsis.adiFinal(a5);
        listaAsis.adiFinal(a6);
        listaAsis.adiFinal(a7);
        listaAsis.adiFinal(a8);
        listaAsis.adiFinal(a9);
        listaAsis.adiFinal(a10);
        
 
        //LISTA PREDEFINIDA DE SOLICITUDES
        listaSoli = new LS_NormalSoli();
        Solicitud s1 = new Solicitud(1, "Vacaciones", "Pendiente");
        Solicitud s2 = new Solicitud(3, "Ascenso", "Pendiente");
        Solicitud s3 = new Solicitud(4, "Recursos", "Pendiente");
        Solicitud s4 = new Solicitud(2, "Licencia por enfermedad", "Pendiente");
        listaSoli.adiFinal(s1);
        listaSoli.adiFinal(s2);
        listaSoli.adiFinal(s3);
        listaSoli.adiFinal(s4);
    }
      
    public void addEmpleado(Empleado x){
        listaEmp.adiFinal(x);
        this.setLocationRelativeTo(null);
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jSeparator1 = new javax.swing.JSeparator();
        lblGrupo = new javax.swing.JLabel();
        lblPrincipal = new javax.swing.JLabel();
        lblBeneficio = new javax.swing.JLabel();
        lblRegistro = new javax.swing.JLabel();
        lblAsistencia = new javax.swing.JLabel();
        lblSolicitud = new javax.swing.JLabel();
        lblExtra = new javax.swing.JLabel();
        lblGrupoMsj1 = new javax.swing.JLabel();
        btnSalir = new javax.swing.JButton();
        jSeparator2 = new javax.swing.JSeparator();
        lblMenu = new javax.swing.JLabel();
        lblFondoSup = new javax.swing.JLabel();
        jTabbedPane1 = new javax.swing.JTabbedPane();
        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTextArea1 = new javax.swing.JTextArea();
        jLabel4 = new javax.swing.JLabel();
        lblGrupoMsj = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        btnRegistro = new javax.swing.JButton();
        btnAgregar = new javax.swing.JButton();
        btnEliminar = new javax.swing.JButton();
        btnEditar = new javax.swing.JButton();
        btnBuscar = new javax.swing.JButton();
        btnEliminar1 = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        msjAsis = new javax.swing.JLabel();
        msjAsis2 = new javax.swing.JLabel();
        btnMarcar = new javax.swing.JButton();
        btnEli = new javax.swing.JButton();
        btnConsul = new javax.swing.JButton();
        jLabel5 = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        txtBen2 = new javax.swing.JLabel();
        txtBen1 = new javax.swing.JLabel();
        btnConsulBene = new javax.swing.JButton();
        btnAggBene = new javax.swing.JButton();
        btnEliBene = new javax.swing.JButton();
        jLabel6 = new javax.swing.JLabel();
        jPanel5 = new javax.swing.JPanel();
        txtSoli2 = new javax.swing.JLabel();
        txtSoli3 = new javax.swing.JLabel();
        btnAdminSoli = new javax.swing.JButton();
        btnCrearSoli = new javax.swing.JButton();
        jLabel7 = new javax.swing.JLabel();
        jPanel6 = new javax.swing.JPanel();
        txtExtra = new javax.swing.JLabel();
        txtDescuento = new javax.swing.JLabel();
        btnPagoExtra = new javax.swing.JButton();
        btnDescuento = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jSeparator1.setBackground(new java.awt.Color(255, 255, 255));
        jSeparator1.setForeground(new java.awt.Color(255, 255, 255));
        jSeparator1.setOrientation(javax.swing.SwingConstants.VERTICAL);
        jSeparator1.setOpaque(true);
        jSeparator1.setPreferredSize(new java.awt.Dimension(50, 5));
        getContentPane().add(jSeparator1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 110, 220, -1));

        lblGrupo.setFont(new java.awt.Font("Trebuchet MS", 3, 26)); // NOI18N
        lblGrupo.setForeground(new java.awt.Color(255, 255, 255));
        lblGrupo.setText("VIRUSNOT");
        lblGrupo.setDebugGraphicsOptions(javax.swing.DebugGraphics.FLASH_OPTION);
        lblGrupo.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        lblGrupo.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblGrupoMouseClicked(evt);
            }
        });
        getContentPane().add(lblGrupo, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 30, 140, 50));

        lblPrincipal.setFont(new java.awt.Font("Trebuchet MS", 3, 18)); // NOI18N
        lblPrincipal.setForeground(new java.awt.Color(255, 255, 255));
        lblPrincipal.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblPrincipal.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IconosBtn/inicio.png"))); // NOI18N
        lblPrincipal.setText("     Principal        ");
        lblPrincipal.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        lblPrincipal.setHorizontalTextPosition(javax.swing.SwingConstants.LEFT);
        lblPrincipal.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblPrincipalMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                lblPrincipalMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                lblPrincipalMouseExited(evt);
            }
        });
        getContentPane().add(lblPrincipal, new org.netbeans.lib.awtextra.AbsoluteConstraints(-20, 170, 240, 30));

        lblBeneficio.setFont(new java.awt.Font("Trebuchet MS", 3, 18)); // NOI18N
        lblBeneficio.setForeground(new java.awt.Color(255, 255, 255));
        lblBeneficio.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblBeneficio.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IconosBtn/soli2.png"))); // NOI18N
        lblBeneficio.setText("Beneficio       ");
        lblBeneficio.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        lblBeneficio.setHorizontalTextPosition(javax.swing.SwingConstants.LEFT);
        lblBeneficio.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblBeneficioMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                lblBeneficioMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                lblBeneficioMouseExited(evt);
            }
        });
        getContentPane().add(lblBeneficio, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 290, 220, 30));

        lblRegistro.setFont(new java.awt.Font("Trebuchet MS", 3, 18)); // NOI18N
        lblRegistro.setForeground(new java.awt.Color(255, 255, 255));
        lblRegistro.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblRegistro.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IconosBtn/persona2.png"))); // NOI18N
        lblRegistro.setText(" Registro         ");
        lblRegistro.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        lblRegistro.setHorizontalTextPosition(javax.swing.SwingConstants.LEFT);
        lblRegistro.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblRegistroMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                lblRegistroMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                lblRegistroMouseExited(evt);
            }
        });
        getContentPane().add(lblRegistro, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 210, 220, 30));

        lblAsistencia.setFont(new java.awt.Font("Trebuchet MS", 3, 18)); // NOI18N
        lblAsistencia.setForeground(new java.awt.Color(255, 255, 255));
        lblAsistencia.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblAsistencia.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IconosBtn/calendario2.png"))); // NOI18N
        lblAsistencia.setText("   Asistencia      ");
        lblAsistencia.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        lblAsistencia.setHorizontalTextPosition(javax.swing.SwingConstants.LEFT);
        lblAsistencia.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblAsistenciaMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                lblAsistenciaMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                lblAsistenciaMouseExited(evt);
            }
        });
        getContentPane().add(lblAsistencia, new org.netbeans.lib.awtextra.AbsoluteConstraints(-10, 250, 230, 30));

        lblSolicitud.setFont(new java.awt.Font("Trebuchet MS", 3, 18)); // NOI18N
        lblSolicitud.setForeground(new java.awt.Color(255, 255, 255));
        lblSolicitud.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblSolicitud.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IconosBtn/solicitud2.png"))); // NOI18N
        lblSolicitud.setText(" Solicitud        ");
        lblSolicitud.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        lblSolicitud.setHorizontalTextPosition(javax.swing.SwingConstants.LEFT);
        lblSolicitud.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblSolicitudMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                lblSolicitudMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                lblSolicitudMouseExited(evt);
            }
        });
        getContentPane().add(lblSolicitud, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 330, 220, 30));

        lblExtra.setFont(new java.awt.Font("Trebuchet MS", 3, 18)); // NOI18N
        lblExtra.setForeground(new java.awt.Color(255, 255, 255));
        lblExtra.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblExtra.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IconosBtn/monedas2.png"))); // NOI18N
        lblExtra.setText(" Extra             ");
        lblExtra.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        lblExtra.setHorizontalTextPosition(javax.swing.SwingConstants.LEFT);
        lblExtra.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblExtraMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                lblExtraMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                lblExtraMouseExited(evt);
            }
        });
        getContentPane().add(lblExtra, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 370, 220, 30));

        lblGrupoMsj1.setBackground(new java.awt.Color(255, 255, 255));
        lblGrupoMsj1.setFont(new java.awt.Font("Trebuchet MS", 3, 20)); // NOI18N
        lblGrupoMsj1.setForeground(new java.awt.Color(255, 255, 255));
        lblGrupoMsj1.setText("Sistema de gestión de empleados");
        lblGrupoMsj1.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        lblGrupoMsj1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblGrupoMsj1MouseClicked(evt);
            }
        });
        getContentPane().add(lblGrupoMsj1, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 40, 350, 30));

        btnSalir.setBackground(new java.awt.Color(255, 255, 255));
        btnSalir.setFont(new java.awt.Font("Arial Narrow", 1, 30)); // NOI18N
        btnSalir.setForeground(new java.awt.Color(0, 0, 0));
        btnSalir.setText("X");
        btnSalir.setBorder(null);
        btnSalir.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnSalir.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnSalirMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btnSalirMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btnSalirMouseExited(evt);
            }
        });
        getContentPane().add(btnSalir, new org.netbeans.lib.awtextra.AbsoluteConstraints(800, 0, 40, 30));

        jSeparator2.setBackground(new java.awt.Color(153, 153, 153));
        jSeparator2.setOpaque(true);
        getContentPane().add(jSeparator2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        lblMenu.setBackground(new java.awt.Color(153, 255, 255));
        lblMenu.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/fondo2.jpg"))); // NOI18N
        lblMenu.setOpaque(true);
        getContentPane().add(lblMenu, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 220, 470));

        lblFondoSup.setBackground(new java.awt.Color(255, 204, 204));
        lblFondoSup.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/fondo.jpg"))); // NOI18N
        lblFondoSup.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        lblFondoSup.setOpaque(true);
        getContentPane().add(lblFondoSup, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 0, 620, 110));

        jPanel1.setBackground(new java.awt.Color(234, 255, 240));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jScrollPane1.setBackground(new java.awt.Color(204, 204, 255));
        jScrollPane1.setBorder(null);

        jTextArea1.setEditable(false);
        jTextArea1.setBackground(new java.awt.Color(212, 221, 252));
        jTextArea1.setColumns(20);
        jTextArea1.setFont(new java.awt.Font("Trebuchet MS", 0, 14)); // NOI18N
        jTextArea1.setForeground(new java.awt.Color(102, 102, 102));
        jTextArea1.setLineWrap(true);
        jTextArea1.setRows(5);
        jTextArea1.setText("  Sistema de gestion de empleados para empresa.Controle y administre de forma \n  óptima y fácil.\n\n  Esta herramienta le permitirá llevar un control completo y detallado de los \n  empleados de su empresa.\n\n\n  Tendrá acceso a herramientas especiales para tareas específicas , como lo son:\n\n\t● Registro de Empleados\n\t● Control de asistencia\n\t● Gestión de horarios\n\t● Gestión de beneficios\n\t● Gestión de solicitudes\n\t● Cálculo salarial\n\n\t");
        jTextArea1.setAutoscrolls(false);
        jTextArea1.setBorder(null);
        jScrollPane1.setViewportView(jTextArea1);

        jPanel1.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 70, 520, 310));

        jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/Fondo22.jpg"))); // NOI18N
        jLabel4.setOpaque(true);
        jPanel1.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 350, 620, 20));

        lblGrupoMsj.setFont(new java.awt.Font("Segoe UI", 3, 18)); // NOI18N
        lblGrupoMsj.setForeground(new java.awt.Color(102, 102, 102));
        lblGrupoMsj.setText("Bienvenido/a");
        /*
        lblGrupoMsj.setText("Bienvenido(a) " + usuario );
        */
        lblGrupoMsj.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        lblGrupoMsj.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblGrupoMsjMouseClicked(evt);
            }
        });
        jPanel1.add(lblGrupoMsj, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 20, 305, 42));

        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/Fondo22.jpg"))); // NOI18N
        jPanel1.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 10, 620, 370));

        jTabbedPane1.addTab("tab1", jPanel1);

        jPanel2.setBackground(new java.awt.Color(234, 255, 240));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        btnRegistro.setBackground(new java.awt.Color(158,162,214));
        btnRegistro.setBackground(new java.awt.Color(255, 255, 255));
        btnRegistro.setBorderPainted(false);
        btnRegistro.setFont(new java.awt.Font("Trebuchet MS", 0, 14)); // NOI18N
        btnRegistro.setForeground(new java.awt.Color(102, 102, 102));
        btnRegistro.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IconosBtn/lista-del-portapapeles.png"))); // NOI18N
        btnRegistro.setText("Registro");
        btnRegistro.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnRegistro.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnRegistro.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);
        btnRegistro.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btnRegistro.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnRegistroMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btnRegistroMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btnRegistroMouseExited(evt);
            }
        });
        btnRegistro.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRegistroActionPerformed(evt);
            }
        });
        jPanel2.add(btnRegistro, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 50, 120, 110));

        btnAgregar.setBackground(new java.awt.Color(158,162,214));
        btnAgregar.setBackground(new java.awt.Color(255, 255, 255));
        btnAgregar.setFont(new java.awt.Font("Trebuchet MS", 0, 14)); // NOI18N
        btnAgregar.setForeground(new java.awt.Color(102, 102, 102));
        btnAgregar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IconosBtn/agregar-usuario.png"))); // NOI18N
        btnAgregar.setText("Agregar");
        btnAgregar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnAgregar.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnAgregar.setMargin(new java.awt.Insets(2, 25, 3, 14));
        btnAgregar.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);
        btnAgregar.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btnAgregar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnAgregarMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btnAgregarMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btnAgregarMouseExited(evt);
            }
        });
        jPanel2.add(btnAgregar, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 50, 120, 110));

        btnEliminar.setBackground(new java.awt.Color(255, 255, 255));
        btnEliminar.setFont(new java.awt.Font("Trebuchet MS", 0, 14)); // NOI18N
        btnEliminar.setForeground(new java.awt.Color(102, 102, 102));
        btnEliminar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IconosBtn/borrar-usuario.png"))); // NOI18N
        btnEliminar.setText("Eliminar");
        btnEliminar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnEliminar.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnEliminar.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);
        btnEliminar.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btnEliminar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnEliminarMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btnEliminarMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btnEliminarMouseExited(evt);
            }
        });
        btnEliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEliminarActionPerformed(evt);
            }
        });
        jPanel2.add(btnEliminar, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 50, 120, 110));

        btnEditar.setBackground(new java.awt.Color(158,162,214));
        btnEditar.setBackground(new java.awt.Color(255, 255, 255));
        btnEditar.setFont(new java.awt.Font("Trebuchet MS", 0, 14)); // NOI18N
        btnEditar.setForeground(new java.awt.Color(102, 102, 102));
        btnEditar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IconosBtn/lapiz-de-usuario.png"))); // NOI18N
        btnEditar.setText("Editar");
        btnEditar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnEditar.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnEditar.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);
        btnEditar.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btnEditar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnEditarMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btnEditarMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btnEditarMouseExited(evt);
            }
        });
        btnEditar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEditarActionPerformed(evt);
            }
        });
        jPanel2.add(btnEditar, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 210, 120, 110));

        btnBuscar.setBackground(new java.awt.Color(158,162,214));
        btnBuscar.setBackground(new java.awt.Color(255, 255, 255));
        btnBuscar.setFont(new java.awt.Font("Trebuchet MS", 0, 14)); // NOI18N
        btnBuscar.setForeground(new java.awt.Color(102, 102, 102));
        btnBuscar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IconosBtn/buscar-alt.png"))); // NOI18N
        btnBuscar.setText("Buscar");
        btnBuscar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnBuscar.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnBuscar.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);
        btnBuscar.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btnBuscar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnBuscarMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btnBuscarMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btnBuscarMouseExited(evt);
            }
        });
        btnBuscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBuscarActionPerformed(evt);
            }
        });
        jPanel2.add(btnBuscar, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 210, 120, 110));

        btnEliminar1.setBackground(new java.awt.Color(204, 204, 204));
        btnEliminar1.setFont(new java.awt.Font("Trebuchet MS", 0, 14)); // NOI18N
        btnEliminar1.setForeground(new java.awt.Color(102, 102, 102));
        btnEliminar1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnEliminar1.setEnabled(false);
        btnEliminar1.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnEliminar1.setOpaque(true);
        btnEliminar1.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);
        btnEliminar1.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btnEliminar1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnEliminar1MouseClicked(evt);
            }
        });
        btnEliminar1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEliminar1ActionPerformed(evt);
            }
        });
        jPanel2.add(btnEliminar1, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 210, 120, 110));

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/Fondo22.jpg"))); // NOI18N
        jPanel2.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 10, 620, 360));

        jTabbedPane1.addTab("tab2", jPanel2);

        jPanel3.setBackground(new java.awt.Color(234, 255, 240));
        jPanel3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        msjAsis.setFont(new java.awt.Font("Trebuchet MS", 0, 14)); // NOI18N
        msjAsis.setForeground(new java.awt.Color(102, 102, 102));
        msjAsis.setText("asistencia");
        msjAsis.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        msjAsis.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                msjAsisMouseClicked(evt);
            }
        });
        jPanel3.add(msjAsis, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 190, 70, 40));

        msjAsis2.setFont(new java.awt.Font("Trebuchet MS", 0, 14)); // NOI18N
        msjAsis2.setForeground(new java.awt.Color(102, 102, 102));
        msjAsis2.setText("asistencia");
        msjAsis2.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        msjAsis2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                msjAsis2MouseClicked(evt);
            }
        });
        jPanel3.add(msjAsis2, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 190, 70, 40));

        btnMarcar.setBackground(new java.awt.Color(255, 255, 255));
        btnMarcar.setFont(new java.awt.Font("Trebuchet MS", 0, 14)); // NOI18N
        btnMarcar.setForeground(new java.awt.Color(102, 102, 102));
        btnMarcar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IconosBtn/marcar-calendario.png"))); // NOI18N
        btnMarcar.setText("Marcar");
        btnMarcar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnMarcar.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnMarcar.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btnMarcar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnMarcarMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btnMarcarMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btnMarcarMouseExited(evt);
            }
        });
        btnMarcar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnMarcarActionPerformed(evt);
            }
        });
        jPanel3.add(btnMarcar, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 100, 120, 130));

        btnEli.setBackground(new java.awt.Color(255, 255, 255));
        btnEli.setFont(new java.awt.Font("Trebuchet MS", 0, 14)); // NOI18N
        btnEli.setForeground(new java.awt.Color(102, 102, 102));
        btnEli.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IconosBtn/eliminar-calendario.png"))); // NOI18N
        btnEli.setText("Eliminar");
        btnEli.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnEli.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnEli.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btnEli.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnEliMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btnEliMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btnEliMouseExited(evt);
            }
        });
        btnEli.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEliActionPerformed(evt);
            }
        });
        jPanel3.add(btnEli, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 100, 120, 130));

        btnConsul.setBackground(new java.awt.Color(255, 255, 255));
        btnConsul.setFont(new java.awt.Font("Trebuchet MS", 0, 14)); // NOI18N
        btnConsul.setForeground(new java.awt.Color(102, 102, 102));
        btnConsul.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IconosBtn/consulatr-calendario.png"))); // NOI18N
        btnConsul.setText("Consultar");
        btnConsul.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnConsul.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnConsul.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btnConsul.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnConsulMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btnConsulMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btnConsulMouseExited(evt);
            }
        });
        btnConsul.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnConsulActionPerformed(evt);
            }
        });
        jPanel3.add(btnConsul, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 100, 120, 130));

        jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/Fondo22.jpg"))); // NOI18N
        jPanel3.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 10, 620, 370));

        jTabbedPane1.addTab("tab3", jPanel3);

        jPanel4.setBackground(new java.awt.Color(234, 255, 240));
        jPanel4.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        txtBen2.setFont(new java.awt.Font("Trebuchet MS", 0, 14)); // NOI18N
        txtBen2.setForeground(new java.awt.Color(102, 102, 102));
        txtBen2.setText("Beneficio");
        txtBen2.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        txtBen2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                txtBen2MouseClicked(evt);
            }
        });
        jPanel4.add(txtBen2, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 190, 80, 40));

        txtBen1.setFont(new java.awt.Font("Trebuchet MS", 0, 14)); // NOI18N
        txtBen1.setForeground(new java.awt.Color(102, 102, 102));
        txtBen1.setText("Beneficio");
        txtBen1.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        txtBen1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                txtBen1MouseClicked(evt);
            }
        });
        jPanel4.add(txtBen1, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 190, 80, 40));

        btnConsulBene.setBackground(new java.awt.Color(255, 255, 255));
        btnConsulBene.setFont(new java.awt.Font("Trebuchet MS", 0, 14)); // NOI18N
        btnConsulBene.setForeground(new java.awt.Color(102, 102, 102));
        btnConsulBene.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IconosBtn/buscar-alt.png"))); // NOI18N
        btnConsulBene.setText("Consultar");
        btnConsulBene.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnConsulBene.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnConsulBene.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btnConsulBene.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnConsulBeneMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btnConsulBeneMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btnConsulBeneMouseExited(evt);
            }
        });
        btnConsulBene.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnConsulBeneActionPerformed(evt);
            }
        });
        jPanel4.add(btnConsulBene, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 100, 120, 130));

        btnAggBene.setBackground(new java.awt.Color(255, 255, 255));
        btnAggBene.setFont(new java.awt.Font("Trebuchet MS", 0, 14)); // NOI18N
        btnAggBene.setForeground(new java.awt.Color(102, 102, 102));
        btnAggBene.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IconosBtn/mano2.png"))); // NOI18N
        btnAggBene.setText("Agregar");
        btnAggBene.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnAggBene.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnAggBene.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btnAggBene.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnAggBeneMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btnAggBeneMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btnAggBeneMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                btnAggBeneMousePressed(evt);
            }
        });
        btnAggBene.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAggBeneActionPerformed(evt);
            }
        });
        jPanel4.add(btnAggBene, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 100, 120, 130));

        btnEliBene.setBackground(new java.awt.Color(255, 255, 255));
        btnEliBene.setFont(new java.awt.Font("Trebuchet MS", 0, 14)); // NOI18N
        btnEliBene.setForeground(new java.awt.Color(102, 102, 102));
        btnEliBene.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IconosBtn/basura.png"))); // NOI18N
        btnEliBene.setText("Eliminar");
        btnEliBene.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnEliBene.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnEliBene.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btnEliBene.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnEliBeneMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btnEliBeneMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btnEliBeneMouseExited(evt);
            }
        });
        btnEliBene.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEliBeneActionPerformed(evt);
            }
        });
        jPanel4.add(btnEliBene, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 100, 120, 130));

        jLabel6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/Fondo22.jpg"))); // NOI18N
        jPanel4.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 10, 620, 370));

        jTabbedPane1.addTab("tab4", jPanel4);

        jPanel5.setBackground(new java.awt.Color(234, 255, 240));
        jPanel5.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        txtSoli2.setFont(new java.awt.Font("Trebuchet MS", 0, 14)); // NOI18N
        txtSoli2.setForeground(new java.awt.Color(102, 102, 102));
        txtSoli2.setText("Solicitud");
        txtSoli2.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        txtSoli2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                txtSoli2MouseClicked(evt);
            }
        });
        jPanel5.add(txtSoli2, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 190, 80, 40));

        txtSoli3.setFont(new java.awt.Font("Trebuchet MS", 0, 14)); // NOI18N
        txtSoli3.setForeground(new java.awt.Color(102, 102, 102));
        txtSoli3.setText("Solicitud");
        txtSoli3.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        txtSoli3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                txtSoli3MouseClicked(evt);
            }
        });
        jPanel5.add(txtSoli3, new org.netbeans.lib.awtextra.AbsoluteConstraints(393, 190, 60, 40));

        btnAdminSoli.setBackground(new java.awt.Color(255, 255, 255));
        btnAdminSoli.setFont(new java.awt.Font("Trebuchet MS", 0, 14)); // NOI18N
        btnAdminSoli.setForeground(new java.awt.Color(102, 102, 102));
        btnAdminSoli.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IconosBtn/alt-administrador.png"))); // NOI18N
        btnAdminSoli.setText("Administrar");
        btnAdminSoli.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnAdminSoli.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnAdminSoli.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btnAdminSoli.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnAdminSoliMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btnAdminSoliMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btnAdminSoliMouseExited(evt);
            }
        });
        btnAdminSoli.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAdminSoliActionPerformed(evt);
            }
        });
        jPanel5.add(btnAdminSoli, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 100, 120, 130));

        btnCrearSoli.setBackground(new java.awt.Color(255, 255, 255));
        btnCrearSoli.setFont(new java.awt.Font("Trebuchet MS", 0, 14)); // NOI18N
        btnCrearSoli.setForeground(new java.awt.Color(102, 102, 102));
        btnCrearSoli.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IconosBtn/agregar-solicitud.png"))); // NOI18N
        btnCrearSoli.setText("Crear");
        btnCrearSoli.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnCrearSoli.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnCrearSoli.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btnCrearSoli.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnCrearSoliMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btnCrearSoliMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btnCrearSoliMouseExited(evt);
            }
        });
        btnCrearSoli.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCrearSoliActionPerformed(evt);
            }
        });
        jPanel5.add(btnCrearSoli, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 100, 120, 130));

        jLabel7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/Fondo22.jpg"))); // NOI18N
        jPanel5.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 10, 620, 370));

        jTabbedPane1.addTab("tab5", jPanel5);

        jPanel6.setBackground(new java.awt.Color(234, 255, 240));
        jPanel6.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        txtExtra.setFont(new java.awt.Font("Trebuchet MS", 0, 14)); // NOI18N
        txtExtra.setForeground(new java.awt.Color(102, 102, 102));
        txtExtra.setText("Sueldo Extra");
        txtExtra.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        txtExtra.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                txtExtraMouseClicked(evt);
            }
        });
        jPanel6.add(txtExtra, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 190, 80, 40));

        txtDescuento.setFont(new java.awt.Font("Trebuchet MS", 0, 14)); // NOI18N
        txtDescuento.setForeground(new java.awt.Color(102, 102, 102));
        txtDescuento.setText("Descuento");
        txtDescuento.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        txtDescuento.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                txtDescuentoMouseClicked(evt);
            }
        });
        jPanel6.add(txtDescuento, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 190, 80, 40));

        btnPagoExtra.setBackground(new java.awt.Color(255, 255, 255));
        btnPagoExtra.setFont(new java.awt.Font("Trebuchet MS", 0, 14)); // NOI18N
        btnPagoExtra.setForeground(new java.awt.Color(102, 102, 102));
        btnPagoExtra.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IconosBtn/calculadora-sencilla.png"))); // NOI18N
        btnPagoExtra.setText("Calcular");
        btnPagoExtra.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnPagoExtra.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnPagoExtra.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btnPagoExtra.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnPagoExtraMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btnPagoExtraMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btnPagoExtraMouseExited(evt);
            }
        });
        btnPagoExtra.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnPagoExtraActionPerformed(evt);
            }
        });
        jPanel6.add(btnPagoExtra, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 100, 120, 130));

        btnDescuento.setBackground(new java.awt.Color(255, 255, 255));
        btnDescuento.setFont(new java.awt.Font("Trebuchet MS", 0, 14)); // NOI18N
        btnDescuento.setForeground(new java.awt.Color(102, 102, 102));
        btnDescuento.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IconosBtn/descuento.png"))); // NOI18N
        btnDescuento.setText("Calcular");
        btnDescuento.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnDescuento.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnDescuento.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btnDescuento.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnDescuentoMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btnDescuentoMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btnDescuentoMouseExited(evt);
            }
        });
        btnDescuento.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDescuentoActionPerformed(evt);
            }
        });
        jPanel6.add(btnDescuento, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 100, 120, 130));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/22Fondo.jpg"))); // NOI18N
        jPanel6.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 10, 620, 360));

        jTabbedPane1.addTab("tab6", jPanel6);

        getContentPane().add(jTabbedPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 70, 620, 400));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void cambiarColorIcono(JLabel label, int red, int green, int blue) {
    Icon iconoOri = label.getIcon();
    if (iconoOri instanceof ImageIcon) {
        Image imagenOri = ((ImageIcon) iconoOri).getImage();
        BufferedImage nueva = new BufferedImage(
                imagenOri.getWidth(null), imagenOri.getHeight(null),
                BufferedImage.TYPE_INT_ARGB);
        Graphics2D g = nueva.createGraphics();
        g.drawImage(imagenOri, 0, 0, null);
        g.setColor(new Color(red, green, blue));
        g.setComposite(AlphaComposite.SrcAtop);
        g.fillRect(0, 0, nueva.getWidth(), nueva.getHeight());
        g.dispose();
        label.setIcon(new ImageIcon(nueva));
    }
}
    
    private void lblGrupoMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblGrupoMouseClicked
    }//GEN-LAST:event_lblGrupoMouseClicked

    private void lblExtraMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblExtraMouseClicked
          jTabbedPane1.setSelectedIndex(5);
    }//GEN-LAST:event_lblExtraMouseClicked

    private void lblPrincipalMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblPrincipalMouseClicked
        jTabbedPane1.setSelectedIndex(0);
    }//GEN-LAST:event_lblPrincipalMouseClicked

    private void lblRegistroMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblRegistroMouseClicked
         jTabbedPane1.setSelectedIndex(1);
    }//GEN-LAST:event_lblRegistroMouseClicked

    private void lblAsistenciaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblAsistenciaMouseClicked
        jTabbedPane1.setSelectedIndex(2);
    }//GEN-LAST:event_lblAsistenciaMouseClicked

    private void lblBeneficioMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblBeneficioMouseClicked
        jTabbedPane1.setSelectedIndex(3);
    }//GEN-LAST:event_lblBeneficioMouseClicked

    private void lblSolicitudMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblSolicitudMouseClicked
        jTabbedPane1.setSelectedIndex(4);
    }//GEN-LAST:event_lblSolicitudMouseClicked

    private void lblGrupoMsjMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblGrupoMsjMouseClicked
    }//GEN-LAST:event_lblGrupoMsjMouseClicked

    private void btnSalirMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnSalirMouseClicked
        System.exit(0);
    }//GEN-LAST:event_btnSalirMouseClicked

    private void lblGrupoMsj1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblGrupoMsj1MouseClicked
    }//GEN-LAST:event_lblGrupoMsj1MouseClicked

    private void btnRegistroMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnRegistroMouseClicked
    }//GEN-LAST:event_btnRegistroMouseClicked

    private void btnAgregarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnAgregarMouseClicked
        SwingUtilities.invokeLater(()->{
            AgregarR nuevo = new AgregarR();
            nuevo.setVisible(true);
            nuevo.setLocationRelativeTo(null);
        });
    }//GEN-LAST:event_btnAgregarMouseClicked

    private void btnEliminarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnEliminarMouseClicked
    }//GEN-LAST:event_btnEliminarMouseClicked

    private void btnEditarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnEditarMouseClicked
    }//GEN-LAST:event_btnEditarMouseClicked

    private void btnBuscarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnBuscarMouseClicked
    }//GEN-LAST:event_btnBuscarMouseClicked

    private void btnRegistroActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRegistroActionPerformed
        SwingUtilities.invokeLater(()->{
            RegistroR nuevo = new RegistroR();
            nuevo.setVisible(true);
            nuevo.setLocationRelativeTo(null);
        });
    }//GEN-LAST:event_btnRegistroActionPerformed

    private void btnEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEliminarActionPerformed
          SwingUtilities.invokeLater(()->{
            EliminarR nuevo = new EliminarR();
            nuevo.setVisible(true);
            nuevo.setLocationRelativeTo(null);
        });
    }//GEN-LAST:event_btnEliminarActionPerformed

    private void btnEditarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEditarActionPerformed
          SwingUtilities.invokeLater(()->{
            EditarR nuevo = new EditarR();
            nuevo.setVisible(true);
            nuevo.setLocationRelativeTo(null);
        });
    }//GEN-LAST:event_btnEditarActionPerformed

    private void btnBuscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBuscarActionPerformed
          SwingUtilities.invokeLater(()->{
            BuscarR nuevo = new BuscarR();
            nuevo.setVisible(true);
            nuevo.setLocationRelativeTo(null);
        });
    }//GEN-LAST:event_btnBuscarActionPerformed

    private void btnMarcarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnMarcarMouseClicked
    }//GEN-LAST:event_btnMarcarMouseClicked

    private void btnMarcarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnMarcarActionPerformed
          SwingUtilities.invokeLater(()->{
            MarcarA nuevo = new MarcarA(listaAsis);
            nuevo.setVisible(true);
            nuevo.setLocationRelativeTo(null);
        });
    }//GEN-LAST:event_btnMarcarActionPerformed

    private void btnEliMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnEliMouseClicked
    }//GEN-LAST:event_btnEliMouseClicked

    private void btnEliActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEliActionPerformed
          SwingUtilities.invokeLater(()->{
            EliminarA nuevo = new EliminarA();
            nuevo.setVisible(true);
            nuevo.setLocationRelativeTo(null);
        });
    }//GEN-LAST:event_btnEliActionPerformed

    private void btnConsulMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnConsulMouseClicked
    }//GEN-LAST:event_btnConsulMouseClicked

    private void btnConsulActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnConsulActionPerformed
         SwingUtilities.invokeLater(()->{
            ConsultarA nuevo = new ConsultarA();
            nuevo.setVisible(true);
            nuevo.setLocationRelativeTo(null);
        });
    }//GEN-LAST:event_btnConsulActionPerformed

    private void msjAsisMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_msjAsisMouseClicked
    }//GEN-LAST:event_msjAsisMouseClicked

    private void msjAsis2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_msjAsis2MouseClicked
    }//GEN-LAST:event_msjAsis2MouseClicked

    private void btnConsulBeneMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnConsulBeneMouseClicked
    }//GEN-LAST:event_btnConsulBeneMouseClicked

    private void btnConsulBeneActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnConsulBeneActionPerformed
           SwingUtilities.invokeLater(()->{
            ConsultarB nuevo = new ConsultarB();
            nuevo.setVisible(true);
            nuevo.setLocationRelativeTo(null);
        });
    }//GEN-LAST:event_btnConsulBeneActionPerformed

    private void btnAggBeneMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnAggBeneMouseClicked
    }//GEN-LAST:event_btnAggBeneMouseClicked

    private void btnAggBeneActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAggBeneActionPerformed
         SwingUtilities.invokeLater(()->{
            AgregarB nuevo = new AgregarB();
            nuevo.setVisible(true);
            nuevo.setLocationRelativeTo(null);
        });
    }//GEN-LAST:event_btnAggBeneActionPerformed

    private void btnEliBeneMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnEliBeneMouseClicked
    }//GEN-LAST:event_btnEliBeneMouseClicked

    private void btnEliBeneActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEliBeneActionPerformed
           SwingUtilities.invokeLater(()->{
            EliminarB nuevo = new EliminarB();
            nuevo.setVisible(true);
            nuevo.setLocationRelativeTo(null);
        });
    }//GEN-LAST:event_btnEliBeneActionPerformed

    private void txtBen2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtBen2MouseClicked
    }//GEN-LAST:event_txtBen2MouseClicked

    private void txtBen1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtBen1MouseClicked
    }//GEN-LAST:event_txtBen1MouseClicked

    private void btnCrearSoliMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnCrearSoliMouseClicked
    }//GEN-LAST:event_btnCrearSoliMouseClicked

    private void btnCrearSoliActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCrearSoliActionPerformed
        SwingUtilities.invokeLater(()->{
            CrearS nuevo = new CrearS();
            nuevo.setVisible(true);
            nuevo.setLocationRelativeTo(null);
        });
    }//GEN-LAST:event_btnCrearSoliActionPerformed

    private void btnAdminSoliMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnAdminSoliMouseClicked
    }//GEN-LAST:event_btnAdminSoliMouseClicked

    private void btnAdminSoliActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAdminSoliActionPerformed
        SwingUtilities.invokeLater(()->{
            AdministrarS nuevo = new AdministrarS();
            nuevo.setVisible(true);
            nuevo.setLocationRelativeTo(null);
        });
    }//GEN-LAST:event_btnAdminSoliActionPerformed

    private void lblPrincipalMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblPrincipalMouseEntered
        lblPrincipal.setBackground(new Color(204, 204, 255));
        lblPrincipal.setOpaque(true);
        lblPrincipal.setForeground(new Color(157, 146, 215));
        cambiarColorIcono(lblPrincipal, 157, 146, 215);
    }//GEN-LAST:event_lblPrincipalMouseEntered

    private void lblRegistroMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblRegistroMouseEntered
        lblRegistro.setBackground(new Color(204, 204, 255));
        lblRegistro.setOpaque(true);
        lblRegistro.setForeground(new Color(157, 146, 215));
        cambiarColorIcono(lblRegistro, 157, 146, 215);
    }//GEN-LAST:event_lblRegistroMouseEntered

    private void lblAsistenciaMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblAsistenciaMouseEntered
        lblAsistencia.setBackground(new Color(204, 204, 255));
        lblAsistencia.setOpaque(true);
        lblAsistencia.setForeground(new Color(157, 146, 215));
        cambiarColorIcono(lblAsistencia, 157, 146, 215);
    }//GEN-LAST:event_lblAsistenciaMouseEntered

    private void lblBeneficioMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblBeneficioMouseEntered
        lblBeneficio.setBackground(new Color(204, 204, 255));
        lblBeneficio.setOpaque(true);
        lblBeneficio.setForeground(new Color(157, 146, 215));
        cambiarColorIcono(lblBeneficio, 157, 146, 215);
    }//GEN-LAST:event_lblBeneficioMouseEntered

    private void lblSolicitudMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblSolicitudMouseEntered
        lblSolicitud.setBackground(new Color(204, 204, 255));
        lblSolicitud.setOpaque(true);
        lblSolicitud.setForeground(new Color(157, 146, 215));
        cambiarColorIcono(lblSolicitud, 157, 146, 215);
    }//GEN-LAST:event_lblSolicitudMouseEntered

    private void lblExtraMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblExtraMouseEntered
        lblExtra.setBackground(new Color(204, 204, 255));
        lblExtra.setOpaque(true);
        lblExtra.setForeground(new Color(157, 146, 215));
        cambiarColorIcono(lblExtra, 157, 146, 215);
    }//GEN-LAST:event_lblExtraMouseEntered

    private void lblPrincipalMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblPrincipalMouseExited
        lblPrincipal.setBackground(Color.WHITE);
        lblPrincipal.setOpaque(false);
        lblPrincipal.setForeground(Color.WHITE);
        cambiarColorIcono(lblPrincipal, 255, 255, 255);
    }//GEN-LAST:event_lblPrincipalMouseExited

    private void lblRegistroMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblRegistroMouseExited
        lblRegistro.setBackground(Color.WHITE);
        lblRegistro.setOpaque(false);
        lblRegistro.setForeground(Color.WHITE);
        cambiarColorIcono(lblRegistro, 255, 255, 255);
    }//GEN-LAST:event_lblRegistroMouseExited

    private void lblAsistenciaMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblAsistenciaMouseExited
        lblAsistencia.setBackground(Color.WHITE);
        lblAsistencia.setOpaque(false);
        lblAsistencia.setForeground(Color.WHITE);
        cambiarColorIcono(lblAsistencia, 255, 255, 255);
    }//GEN-LAST:event_lblAsistenciaMouseExited

    private void lblBeneficioMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblBeneficioMouseExited
        lblBeneficio.setBackground(Color.WHITE);
        lblBeneficio.setOpaque(false);
        lblBeneficio.setForeground(Color.WHITE);
        cambiarColorIcono(lblBeneficio, 255, 255, 255);
    }//GEN-LAST:event_lblBeneficioMouseExited

    private void lblSolicitudMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblSolicitudMouseExited
        lblSolicitud.setBackground(Color.WHITE);
        lblSolicitud.setOpaque(false);
        lblSolicitud.setForeground(Color.WHITE);
        cambiarColorIcono(lblSolicitud, 255, 255, 255);
    }//GEN-LAST:event_lblSolicitudMouseExited

    private void lblExtraMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblExtraMouseExited
        lblExtra.setBackground(Color.WHITE);
        lblExtra.setOpaque(false);
        lblExtra.setForeground(Color.WHITE);
        cambiarColorIcono(lblExtra, 255, 255, 255);
    }//GEN-LAST:event_lblExtraMouseExited

    private void btnSalirMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnSalirMouseEntered
        btnSalir.setBackground(Color.red);
        btnSalir.setForeground(Color.white);
    }//GEN-LAST:event_btnSalirMouseEntered

    private void btnSalirMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnSalirMouseExited
        btnSalir.setBackground(Color.white);
        btnSalir.setForeground(Color.black);
    }//GEN-LAST:event_btnSalirMouseExited

    private void txtSoli3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtSoli3MouseClicked
    }//GEN-LAST:event_txtSoli3MouseClicked

    private void txtSoli2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtSoli2MouseClicked
    }//GEN-LAST:event_txtSoli2MouseClicked

    private void btnEliminar1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnEliminar1MouseClicked
    }//GEN-LAST:event_btnEliminar1MouseClicked

    private void btnEliminar1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEliminar1ActionPerformed
    }//GEN-LAST:event_btnEliminar1ActionPerformed

    private void btnRegistroMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnRegistroMouseEntered
        btnRegistro.setBackground(new Color(161, 162, 214));
        btnRegistro.setForeground(new Color(141, 137, 210));
        
    }//GEN-LAST:event_btnRegistroMouseEntered
    
    private void btnRegistroMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnRegistroMouseExited
        btnRegistro.setBackground(Color.white);
        btnRegistro.setForeground(new Color(102, 102, 102));
    }//GEN-LAST:event_btnRegistroMouseExited

    private void btnAgregarMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnAgregarMouseEntered
        btnAgregar.setBackground(new Color(161, 162, 214));
        btnAgregar.setForeground(new Color(141, 137, 210));
    }//GEN-LAST:event_btnAgregarMouseEntered

    private void btnAgregarMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnAgregarMouseExited
        btnAgregar.setBackground(Color.white);
        btnAgregar.setForeground(new Color(102, 102, 102));
    }//GEN-LAST:event_btnAgregarMouseExited

    private void btnEliminarMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnEliminarMouseEntered
        btnEliminar.setBackground(new Color(161, 162, 214));
        btnEliminar.setForeground(new Color(141, 137, 210));
    }//GEN-LAST:event_btnEliminarMouseEntered

    private void btnEliminarMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnEliminarMouseExited
        btnEliminar.setBackground(Color.white);
        btnEliminar.setForeground(new Color(102, 102, 102));

    }//GEN-LAST:event_btnEliminarMouseExited

    private void btnEditarMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnEditarMouseEntered
        btnEditar.setBackground(new Color(161, 162, 214));
        btnEditar.setForeground(new Color(141, 137, 210));
    }//GEN-LAST:event_btnEditarMouseEntered

    private void btnEditarMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnEditarMouseExited
        btnEditar.setBackground(Color.white);
        btnEditar.setForeground(new Color(102, 102, 102));
    }//GEN-LAST:event_btnEditarMouseExited

    private void btnBuscarMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnBuscarMouseEntered
        btnBuscar.setBackground(new Color(161, 162, 214));
        btnBuscar.setForeground(new Color(141, 137, 210));
    }//GEN-LAST:event_btnBuscarMouseEntered

    private void btnBuscarMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnBuscarMouseExited
        btnBuscar.setBackground(Color.white);
        btnBuscar.setForeground(new Color(102, 102, 102));
    }//GEN-LAST:event_btnBuscarMouseExited

    private void btnMarcarMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnMarcarMouseEntered
        btnMarcar.setBackground(new Color(161, 162, 214));
        btnMarcar.setForeground(new Color(141, 137, 210));
        msjAsis2.setForeground(new Color(141, 137, 210));
    }//GEN-LAST:event_btnMarcarMouseEntered

    private void btnMarcarMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnMarcarMouseExited
        btnMarcar.setBackground(Color.white);
        btnMarcar.setForeground(new Color(102, 102, 102));
        msjAsis2.setForeground(new Color(102, 102, 102));
    }//GEN-LAST:event_btnMarcarMouseExited

    private void btnEliMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnEliMouseEntered
        btnEli.setBackground(new Color(161, 162, 214));
        btnEli.setForeground(new Color(141, 137, 210));
        msjAsis.setForeground(new Color(141, 137, 210));
    }//GEN-LAST:event_btnEliMouseEntered

    private void btnEliMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnEliMouseExited
        btnEli.setBackground(Color.white);
        btnEli.setForeground(new Color(102, 102, 102));
        msjAsis.setForeground(new Color(102, 102, 102));
    }//GEN-LAST:event_btnEliMouseExited

    private void btnConsulMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnConsulMouseEntered
        btnConsul.setBackground(new Color(161, 162, 214));
        btnConsul.setForeground(new Color(141, 137, 210));
    }//GEN-LAST:event_btnConsulMouseEntered

    private void btnConsulMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnConsulMouseExited
        btnConsul.setBackground(Color.white);
        btnConsul.setForeground(new Color(102, 102, 102));
    }//GEN-LAST:event_btnConsulMouseExited

    private void btnAggBeneMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnAggBeneMouseEntered
        btnAggBene.setBackground(new Color(161, 162, 214));
        btnAggBene.setForeground(new Color(141, 137, 210));
        txtBen1.setForeground(new Color(141, 137, 210));
    }//GEN-LAST:event_btnAggBeneMouseEntered

    private void btnAggBeneMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnAggBeneMousePressed
    }//GEN-LAST:event_btnAggBeneMousePressed

    private void btnAggBeneMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnAggBeneMouseExited
        btnAggBene.setBackground(Color.white);
        btnAggBene.setForeground(new Color(102, 102, 102));
        txtBen1.setForeground(new Color(102, 102, 102));
    }//GEN-LAST:event_btnAggBeneMouseExited

    private void btnEliBeneMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnEliBeneMouseEntered
        btnEliBene.setBackground(new Color(161, 162, 214));
        btnEliBene.setForeground(new Color(141, 137, 210));
        txtBen2.setForeground(new Color(141, 137, 210));
    }//GEN-LAST:event_btnEliBeneMouseEntered

    private void btnEliBeneMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnEliBeneMouseExited
        btnEliBene.setBackground(Color.white);
        btnEliBene.setForeground(new Color(102, 102, 102));
        txtBen2.setForeground(new Color(102, 102, 102));
    }//GEN-LAST:event_btnEliBeneMouseExited

    private void btnConsulBeneMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnConsulBeneMouseEntered
        btnConsulBene.setBackground(new Color(161, 162, 214));
        btnConsulBene.setForeground(new Color(141, 137, 210));
        txtBen2.setForeground(new Color(141, 137, 210));
    }//GEN-LAST:event_btnConsulBeneMouseEntered

    private void btnConsulBeneMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnConsulBeneMouseExited
        btnConsulBene.setBackground(Color.white);
        btnConsulBene.setForeground(new Color(102, 102, 102));
        txtBen2.setForeground(new Color(102, 102, 102));
    }//GEN-LAST:event_btnConsulBeneMouseExited

    private void btnCrearSoliMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnCrearSoliMouseEntered
        btnCrearSoli.setBackground(new Color(161, 162, 214));
        btnCrearSoli.setForeground(new Color(141, 137, 210));
        txtSoli2.setForeground(new Color(141, 137, 210));
    }//GEN-LAST:event_btnCrearSoliMouseEntered

    private void btnCrearSoliMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnCrearSoliMouseExited
        btnCrearSoli.setBackground(Color.white);
        btnCrearSoli.setForeground(new Color(102, 102, 102));
        txtSoli2.setForeground(new Color(102, 102, 102));
    }//GEN-LAST:event_btnCrearSoliMouseExited

    private void btnAdminSoliMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnAdminSoliMouseEntered
        btnAdminSoli.setBackground(new Color(161, 162, 214));
        btnAdminSoli.setForeground(new Color(141, 137, 210));
        txtSoli3.setForeground(new Color(141, 137, 210));
    }//GEN-LAST:event_btnAdminSoliMouseEntered

    private void btnAdminSoliMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnAdminSoliMouseExited
        btnAdminSoli.setBackground(Color.white);
        btnAdminSoli.setForeground(new Color(102, 102, 102));
        txtSoli3.setForeground(new Color(102, 102, 102));
    }//GEN-LAST:event_btnAdminSoliMouseExited

    private void btnPagoExtraMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnPagoExtraMouseClicked
    }//GEN-LAST:event_btnPagoExtraMouseClicked

    private void btnPagoExtraMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnPagoExtraMouseEntered
        btnPagoExtra.setBackground(new Color(161, 162, 214));
        btnPagoExtra.setForeground(new Color(141, 137, 210));
        txtExtra.setForeground(new Color(141, 137, 210));
    }//GEN-LAST:event_btnPagoExtraMouseEntered

    private void btnPagoExtraMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnPagoExtraMouseExited
        btnPagoExtra.setBackground(Color.white);
        btnPagoExtra.setForeground(new Color(102, 102, 102));
        txtExtra.setForeground(new Color(102, 102, 102));
    }//GEN-LAST:event_btnPagoExtraMouseExited

    private void btnPagoExtraActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPagoExtraActionPerformed
         SwingUtilities.invokeLater(()->{
            PagoExtra nuevo = new PagoExtra();
            nuevo.setVisible(true);
            nuevo.setLocationRelativeTo(null);
        });
    }//GEN-LAST:event_btnPagoExtraActionPerformed

    private void btnDescuentoMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnDescuentoMouseClicked
    }//GEN-LAST:event_btnDescuentoMouseClicked

    private void btnDescuentoMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnDescuentoMouseEntered
        btnDescuento.setBackground(new Color(161, 162, 214));
        btnDescuento.setForeground(new Color(141, 137, 210));
        txtDescuento.setForeground(new Color(141, 137, 210));
    }//GEN-LAST:event_btnDescuentoMouseEntered

    private void btnDescuentoMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnDescuentoMouseExited
        btnDescuento.setBackground(Color.white);
        btnDescuento.setForeground(new Color(102, 102, 102));
        txtDescuento.setForeground(new Color(102, 102, 102));
    }//GEN-LAST:event_btnDescuentoMouseExited

    private void btnDescuentoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDescuentoActionPerformed
        SwingUtilities.invokeLater(()->{
            Descuento nuevo = new Descuento();
            nuevo.setVisible(true);
            nuevo.setLocationRelativeTo(null);
        });
    }//GEN-LAST:event_btnDescuentoActionPerformed

    private void txtExtraMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtExtraMouseClicked
    }//GEN-LAST:event_txtExtraMouseClicked

    private void txtDescuentoMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtDescuentoMouseClicked
    }//GEN-LAST:event_txtDescuentoMouseClicked

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(FrmPrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(FrmPrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(FrmPrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(FrmPrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new FrmPrincipal().setVisible(true);
            }
        });
       
    }
    
  
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAdminSoli;
    private javax.swing.JButton btnAggBene;
    private javax.swing.JButton btnAgregar;
    private javax.swing.JButton btnBuscar;
    private javax.swing.JButton btnConsul;
    private javax.swing.JButton btnConsulBene;
    private javax.swing.JButton btnCrearSoli;
    private javax.swing.JButton btnDescuento;
    private javax.swing.JButton btnEditar;
    private javax.swing.JButton btnEli;
    private javax.swing.JButton btnEliBene;
    private javax.swing.JButton btnEliminar;
    private javax.swing.JButton btnEliminar1;
    private javax.swing.JButton btnMarcar;
    private javax.swing.JButton btnPagoExtra;
    private javax.swing.JButton btnRegistro;
    private javax.swing.JButton btnSalir;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JSeparator jSeparator2;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JTextArea jTextArea1;
    private javax.swing.JLabel lblAsistencia;
    private javax.swing.JLabel lblBeneficio;
    private javax.swing.JLabel lblExtra;
    private javax.swing.JLabel lblFondoSup;
    private javax.swing.JLabel lblGrupo;
    private javax.swing.JLabel lblGrupoMsj;
    private javax.swing.JLabel lblGrupoMsj1;
    private javax.swing.JLabel lblMenu;
    private javax.swing.JLabel lblPrincipal;
    private javax.swing.JLabel lblRegistro;
    private javax.swing.JLabel lblSolicitud;
    private javax.swing.JLabel msjAsis;
    private javax.swing.JLabel msjAsis2;
    private javax.swing.JLabel txtBen1;
    private javax.swing.JLabel txtBen2;
    private javax.swing.JLabel txtDescuento;
    private javax.swing.JLabel txtExtra;
    private javax.swing.JLabel txtSoli2;
    private javax.swing.JLabel txtSoli3;
    // End of variables declaration//GEN-END:variables
}
