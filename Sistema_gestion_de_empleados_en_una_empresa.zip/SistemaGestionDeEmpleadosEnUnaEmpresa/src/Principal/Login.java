/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package Principal;

import java.awt.Color;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;

/**
 *
 * @author Alexis
 */
public class Login extends javax.swing.JFrame {
    private String usuario;
    
    
    public Login() {
        initComponents();
        setIconImage(new ImageIcon(getClass().getResource("/Imagenes/VN.png")).getImage());
        setLocationRelativeTo(null);
        
    }

   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        btnSalir = new javax.swing.JButton();
        txtSaludo = new javax.swing.JLabel();
        btnEntrar = new javax.swing.JButton();
        pswField = new javax.swing.JPasswordField();
        txtFieldUs = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        fondoDe = new javax.swing.JLabel();
        fondoIz = new javax.swing.JLabel();
        fondo = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        btnSalir.setBackground(new java.awt.Color(255, 255, 255));
        btnSalir.setFont(new java.awt.Font("Arial Narrow", 1, 30)); // NOI18N
        btnSalir.setForeground(new java.awt.Color(0, 0, 0));
        btnSalir.setText("X");
        btnSalir.setBorder(null);
        btnSalir.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btnSalirMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btnSalirMouseExited(evt);
            }
        });
        btnSalir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSalirActionPerformed(evt);
            }
        });
        getContentPane().add(btnSalir, new org.netbeans.lib.awtextra.AbsoluteConstraints(810, 0, 40, 30));

        txtSaludo.setFont(new java.awt.Font("Trebuchet MS", 3, 22)); // NOI18N
        txtSaludo.setForeground(new java.awt.Color(137, 82, 246));
        txtSaludo.setText("Bienvenido de nuevo");
        txtSaludo.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        txtSaludo.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                txtSaludoMouseClicked(evt);
            }
        });
        getContentPane().add(txtSaludo, new org.netbeans.lib.awtextra.AbsoluteConstraints(490, 120, 220, 60));

        btnEntrar.setBackground(new java.awt.Color(204, 204, 204));
        btnEntrar.setFont(new java.awt.Font("Trebuchet MS", 2, 16)); // NOI18N
        btnEntrar.setForeground(new java.awt.Color(153, 153, 153));
        btnEntrar.setText("Entrar");
        btnEntrar.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        btnEntrar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnEntrar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btnEntrarMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btnEntrarMouseExited(evt);
            }
        });
        btnEntrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEntrarActionPerformed(evt);
            }
        });
        getContentPane().add(btnEntrar, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 330, 110, 30));

        pswField.setBackground(new java.awt.Color(204, 204, 255));
        pswField.setFont(new java.awt.Font("Trebuchet MS", 2, 14)); // NOI18N
        pswField.setForeground(new java.awt.Color(255, 255, 255));
        pswField.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        pswField.setText("jPasswordField1");
        pswField.setBorder(javax.swing.BorderFactory.createEtchedBorder(java.awt.Color.lightGray, java.awt.Color.gray));
        pswField.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                pswFieldMouseClicked(evt);
            }
        });
        getContentPane().add(pswField, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 260, 190, 30));

        txtFieldUs.setBackground(new java.awt.Color(204, 204, 255));
        txtFieldUs.setFont(new java.awt.Font("Trebuchet MS", 2, 18)); // NOI18N
        txtFieldUs.setForeground(new java.awt.Color(255, 255, 255));
        txtFieldUs.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtFieldUs.setText("USUARIO");
        txtFieldUs.setBorder(javax.swing.BorderFactory.createEtchedBorder(java.awt.Color.lightGray, java.awt.Color.gray));
        txtFieldUs.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                txtFieldUsMouseClicked(evt);
            }
        });
        getContentPane().add(txtFieldUs, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 210, 190, 30));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/22Fondo.jpg"))); // NOI18N
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 73, 247, 324));

        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/lo3.png"))); // NOI18N
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 60, 330, 350));

        fondoDe.setBackground(new java.awt.Color(234, 255, 240));
        fondoDe.setOpaque(true);
        getContentPane().add(fondoDe, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 73, 247, 324));

        fondoIz.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(204, 204, 255), 3, true));
        getContentPane().add(fondoIz, new org.netbeans.lib.awtextra.AbsoluteConstraints(137, 70, 583, 330));

        fondo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/fondo2.jpg"))); // NOI18N
        fondo.setText("jLabel1");
        fondo.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        getContentPane().add(fondo, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 850, 470));

        jPanel1.setBackground(new java.awt.Color(204, 204, 255));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 850, 470));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnSalirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSalirActionPerformed
        System.exit(0);
    }//GEN-LAST:event_btnSalirActionPerformed

    private void txtSaludoMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtSaludoMouseClicked
    }//GEN-LAST:event_txtSaludoMouseClicked

    private void txtFieldUsMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtFieldUsMouseClicked
        txtFieldUs.setText("");
        txtFieldUs.setForeground(new Color(153, 153, 153));
    }//GEN-LAST:event_txtFieldUsMouseClicked

    private void pswFieldMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_pswFieldMouseClicked
        pswField.setText("");
        pswField.setForeground(new Color(153, 153, 153));
    }//GEN-LAST:event_pswFieldMouseClicked

    private void btnEntrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEntrarActionPerformed
        if(evt.getSource() == btnEntrar){
            String us1 = "Alan";
            String us2 = "David";
            String us3 = "Fernanda";
            String us4 = "Maria";
            String us5 = "Rodrigo";
            String  psw = "12345";
            usuario = txtFieldUs.getText();
            String pswLog = pswField.getText();
            if(usuario.isEmpty() || pswLog.isEmpty()){
                JOptionPane.showMessageDialog(this, "Algun campo esta vacio.", "Error de entrada", JOptionPane.ERROR_MESSAGE);
                //JOptionPane.showMessageDialog(null, "Algún campo esta vacío");
            }else{
                if(usuario.equals(us1) || usuario.equals(us2) || usuario.equals(us3) || usuario.equals(us4) || usuario.equals(us5)){
                    if(pswLog.equals(psw)){
                        SwingUtilities.invokeLater(()->{
                           //FrmPrincipal princi = new FrmPrincipal(usuario);
                           FrmPrincipal princi = new FrmPrincipal();
                           princi.setVisible(true);
                           princi.setLocationRelativeTo(null);
			});
			dispose();
                    }
                    else{
                        JOptionPane.showMessageDialog(this, "Contraseña incorrecta.", "Error", JOptionPane.ERROR_MESSAGE);
                        //JOptionPane.showMessageDialog(null, "Usuario y/o contraseña incorrecta");
                    }
                }else{
                    JOptionPane.showMessageDialog(this, "Usuario y/o contraseña incorrecta", "Error", JOptionPane.ERROR_MESSAGE);
                    //JOptionPane.showMessageDialog(null, "Usuario y/o contraseña incorrecta");
                }
            }
        }
    }//GEN-LAST:event_btnEntrarActionPerformed

    private void btnEntrarMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnEntrarMouseEntered
        btnEntrar.setBackground(new Color(161, 162, 214));
        btnEntrar.setForeground(new Color(141, 137, 210));
    }//GEN-LAST:event_btnEntrarMouseEntered

    private void btnEntrarMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnEntrarMouseExited
            btnEntrar.setBackground(new Color(204,204,204));
            btnEntrar.setForeground(new Color(153, 153, 153));
    }//GEN-LAST:event_btnEntrarMouseExited

    private void btnSalirMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnSalirMouseEntered
        btnSalir.setBackground(Color.red);
        btnSalir.setForeground(Color.white);
    }//GEN-LAST:event_btnSalirMouseEntered

    private void btnSalirMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnSalirMouseExited
        btnSalir.setBackground(Color.white);
        btnSalir.setForeground(Color.black);
    }//GEN-LAST:event_btnSalirMouseExited

    
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Login().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnEntrar;
    private javax.swing.JButton btnSalir;
    private javax.swing.JLabel fondo;
    private javax.swing.JLabel fondoDe;
    private javax.swing.JLabel fondoIz;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPasswordField pswField;
    private javax.swing.JTextField txtFieldUs;
    private javax.swing.JLabel txtSaludo;
    // End of variables declaration//GEN-END:variables
}
