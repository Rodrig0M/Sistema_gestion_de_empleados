/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package FrmExtra;

import EDT.Empleado;
import javax.swing.JOptionPane;

/**
 *
 * @author Alexis
 */
public class Descuento extends javax.swing.JFrame {

    public Descuento() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        btnHome3 = new javax.swing.JButton();
        lblGrupo = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        txtId = new javax.swing.JTextField();
        txtFieldId = new javax.swing.JTextField();
        txtFieldHoras = new javax.swing.JTextField();
        txtHoras = new javax.swing.JTextField();
        txtFieldTarifaHora = new javax.swing.JTextField();
        txtTarifaHora = new javax.swing.JTextField();
        btnCalcular = new javax.swing.JButton();
        txtFieldSueldo = new javax.swing.JTextField();
        txtSueldo = new javax.swing.JTextField();
        lblFondoMedio = new javax.swing.JLabel();
        lblFondoMedio1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(234, 255, 240));
        setUndecorated(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        btnHome3.setBackground(new java.awt.Color(107, 139, 216));
        btnHome3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IconosBtn/volver1.png"))); // NOI18N
        btnHome3.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnHome3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnHome3ActionPerformed(evt);
            }
        });
        getContentPane().add(btnHome3, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 20, 40, 40));

        lblGrupo.setFont(new java.awt.Font("Trebuchet MS", 0, 18)); // NOI18N
        lblGrupo.setForeground(new java.awt.Color(204, 204, 204));
        lblGrupo.setText("Extra > Calcular descuento ");
        lblGrupo.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        lblGrupo.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblGrupoMouseClicked(evt);
            }
        });
        getContentPane().add(lblGrupo, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 40, 230, 40));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/fondo2.jpg"))); // NOI18N
        jLabel1.setText("jLabel1");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 840, 80));

        jPanel1.setBackground(new java.awt.Color(212, 221, 252));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        txtId.setEditable(false);
        txtId.setBackground(new java.awt.Color(212, 221, 252));
        txtId.setFont(new java.awt.Font("Trebuchet MS", 0, 12)); // NOI18N
        txtId.setForeground(new java.awt.Color(153, 153, 153));
        txtId.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtId.setText("ID");
        txtId.setBorder(null);
        txtId.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtIdActionPerformed(evt);
            }
        });
        jPanel1.add(txtId, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 130, 60, -1));

        txtFieldId.setFont(new java.awt.Font("Trebuchet MS", 0, 12)); // NOI18N
        txtFieldId.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jPanel1.add(txtFieldId, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 150, 190, -1));

        txtFieldHoras.setFont(new java.awt.Font("Trebuchet MS", 0, 12)); // NOI18N
        txtFieldHoras.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jPanel1.add(txtFieldHoras, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 200, 190, -1));

        txtHoras.setEditable(false);
        txtHoras.setBackground(new java.awt.Color(212, 221, 252));
        txtHoras.setFont(new java.awt.Font("Trebuchet MS", 0, 12)); // NOI18N
        txtHoras.setForeground(new java.awt.Color(153, 153, 153));
        txtHoras.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtHoras.setText("Horas a descontar");
        txtHoras.setBorder(null);
        txtHoras.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtHorasActionPerformed(evt);
            }
        });
        jPanel1.add(txtHoras, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 180, -1, -1));

        txtFieldTarifaHora.setFont(new java.awt.Font("Trebuchet MS", 0, 12)); // NOI18N
        txtFieldTarifaHora.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jPanel1.add(txtFieldTarifaHora, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 260, 190, -1));

        txtTarifaHora.setEditable(false);
        txtTarifaHora.setBackground(new java.awt.Color(212, 221, 252));
        txtTarifaHora.setFont(new java.awt.Font("Trebuchet MS", 0, 12)); // NOI18N
        txtTarifaHora.setForeground(new java.awt.Color(153, 153, 153));
        txtTarifaHora.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtTarifaHora.setText("Tarifa por hora");
        txtTarifaHora.setBorder(null);
        jPanel1.add(txtTarifaHora, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 240, 140, -1));

        btnCalcular.setFont(new java.awt.Font("Trebuchet MS", 0, 14)); // NOI18N
        btnCalcular.setText("Calcular");
        btnCalcular.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCalcularActionPerformed(evt);
            }
        });
        jPanel1.add(btnCalcular, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 300, 110, -1));

        txtFieldSueldo.setEditable(false);
        txtFieldSueldo.setFont(new java.awt.Font("Trebuchet MS", 0, 15)); // NOI18N
        txtFieldSueldo.setForeground(new java.awt.Color(102, 102, 102));
        txtFieldSueldo.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jPanel1.add(txtFieldSueldo, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 380, 190, 40));

        txtSueldo.setEditable(false);
        txtSueldo.setBackground(new java.awt.Color(212, 221, 252));
        txtSueldo.setFont(new java.awt.Font("Trebuchet MS", 0, 12)); // NOI18N
        txtSueldo.setForeground(new java.awt.Color(153, 153, 153));
        txtSueldo.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtSueldo.setText("Sueldo del mes, aplicando el descuento");
        txtSueldo.setBorder(null);
        txtSueldo.setOpaque(true);
        txtSueldo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtSueldoActionPerformed(evt);
            }
        });
        jPanel1.add(txtSueldo, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 360, 290, -1));

        lblFondoMedio.setBackground(new java.awt.Color(153, 102, 255));
        lblFondoMedio.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(204, 153, 255), 3, true));
        jPanel1.add(lblFondoMedio, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 350, 330, 90));

        lblFondoMedio1.setBackground(new java.awt.Color(153, 102, 255));
        lblFondoMedio1.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(204, 153, 255), 3, true));
        lblFondoMedio1.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jPanel1.add(lblFondoMedio1, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 110, 330, 240));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 840, 470));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void lblGrupoMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblGrupoMouseClicked
        //        System.exit(0);
    }//GEN-LAST:event_lblGrupoMouseClicked

    private void txtIdActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtIdActionPerformed

    }//GEN-LAST:event_txtIdActionPerformed

    private void txtHorasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtHorasActionPerformed

    }//GEN-LAST:event_txtHorasActionPerformed

    private void btnCalcularActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCalcularActionPerformed
        try {
            int idx = Integer.parseInt(txtFieldId.getText());
            int hrsTrab = Integer.parseInt(txtFieldHoras.getText());
            double tarHora = Double.parseDouble(txtFieldTarifaHora.getText());
            Empleado em = EDT.Extra.buscarId(idx);
            double sueldoFinal = em.getSueldo();

            if (em != null) {
                double descuento = EDT.Extra.calcularDescuento(em, hrsTrab, tarHora);
                if (descuento != 0) {
                    txtFieldSueldo.setText(String.valueOf(sueldoFinal - descuento));
                } else {
                    JOptionPane.showMessageDialog(this, "Las horas extras y tarifa, deben ser valores positivos.", "Error de entrada", JOptionPane.ERROR_MESSAGE);
                }
            } else {
                JOptionPane.showMessageDialog(this, "No se encontro al empleado con el ID ingresado.", "Error de entrada", JOptionPane.ERROR_MESSAGE);
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Ingrese valores validos.", "Error de entrada", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_btnCalcularActionPerformed

    private void txtSueldoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtSueldoActionPerformed

    }//GEN-LAST:event_txtSueldoActionPerformed

    private void btnHome3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnHome3ActionPerformed
        dispose();
    }//GEN-LAST:event_btnHome3ActionPerformed

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Descuento.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Descuento.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Descuento.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Descuento.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Descuento().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnCalcular;
    private javax.swing.JButton btnHome3;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JLabel lblFondoMedio;
    private javax.swing.JLabel lblFondoMedio1;
    private javax.swing.JLabel lblGrupo;
    private javax.swing.JTextField txtFieldHoras;
    private javax.swing.JTextField txtFieldId;
    private javax.swing.JTextField txtFieldSueldo;
    private javax.swing.JTextField txtFieldTarifaHora;
    private javax.swing.JTextField txtHoras;
    private javax.swing.JTextField txtId;
    private javax.swing.JTextField txtSueldo;
    private javax.swing.JTextField txtTarifaHora;
    // End of variables declaration//GEN-END:variables
}
