/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package FrmAsistencia;

import EDT.Asistencia;
import EDT.LS_NormalAsis;
import EDT.NodoAsis;
import java.util.Date;
import javax.swing.table.DefaultTableModel;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;

/**
 *
 * @author Alexis
 */
public class MarcarA extends javax.swing.JFrame {

    public MarcarA(LS_NormalAsis listaAsis) {
        initComponents();
        setIconImage(new ImageIcon(getClass().getResource("/Imagenes/VN.png")).getImage());

        DefaultTableModel model = (DefaultTableModel) tableAsis.getModel();
        model.setRowCount(0);

        NodoAsis R = listaAsis.getP();
        while (R != null) {
            Asistencia aux = R.getA();
            Object[] rowData = {aux.getId(), aux.getFecha(), aux.getHoraEntrada()};
            model.addRow(rowData);
            R = R.getSig();
        }
    }

    private MarcarA() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        btnHome = new javax.swing.JButton();
        lblGrupo = new javax.swing.JLabel();
        jSeparator1 = new javax.swing.JSeparator();
        txtFecha = new javax.swing.JLabel();
        txtMin = new javax.swing.JLabel();
        txtHra = new javax.swing.JLabel();
        txtFieldId = new javax.swing.JTextField();
        txtId = new javax.swing.JTextField();
        comboBoxHra = new javax.swing.JComboBox<>();
        comboBoxMin = new javax.swing.JComboBox<>();
        btnMarcar = new javax.swing.JButton();
        lblBordeMarcar = new javax.swing.JLabel();
        jScrollPaneAsis = new javax.swing.JScrollPane();
        tableAsis = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();
        dateChooser = new com.toedter.calendar.JDateChooser();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(212, 221, 252));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        btnHome.setBackground(new java.awt.Color(107, 139, 216));
        btnHome.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IconosBtn/volver1.png"))); // NOI18N
        btnHome.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnHome.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnHomeActionPerformed(evt);
            }
        });
        jPanel1.add(btnHome, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 20, 40, 40));

        lblGrupo.setFont(new java.awt.Font("Trebuchet MS", 0, 18)); // NOI18N
        lblGrupo.setForeground(new java.awt.Color(204, 204, 204));
        lblGrupo.setText("Asistencia > Marcar asistencia");
        lblGrupo.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        lblGrupo.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblGrupoMouseClicked(evt);
            }
        });
        jPanel1.add(lblGrupo, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 40, 240, 40));

        jSeparator1.setBackground(new java.awt.Color(153, 153, 153));
        jSeparator1.setForeground(new java.awt.Color(153, 153, 153));
        jSeparator1.setOpaque(true);
        jPanel1.add(jSeparator1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 80, 840, -1));

        txtFecha.setBackground(new java.awt.Color(234, 255, 240));
        txtFecha.setFont(new java.awt.Font("Trebuchet MS", 0, 18)); // NOI18N
        txtFecha.setForeground(new java.awt.Color(153, 153, 153));
        txtFecha.setText("Fecha");
        txtFecha.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        txtFecha.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                txtFechaMouseClicked(evt);
            }
        });
        jPanel1.add(txtFecha, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 120, 140, 40));

        txtMin.setBackground(new java.awt.Color(234, 255, 240));
        txtMin.setFont(new java.awt.Font("Trebuchet MS", 0, 18)); // NOI18N
        txtMin.setForeground(new java.awt.Color(153, 153, 153));
        txtMin.setText("minuto");
        txtMin.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        txtMin.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                txtMinMouseClicked(evt);
            }
        });
        jPanel1.add(txtMin, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 200, 70, 40));

        txtHra.setBackground(new java.awt.Color(234, 255, 240));
        txtHra.setFont(new java.awt.Font("Trebuchet MS", 0, 18)); // NOI18N
        txtHra.setForeground(new java.awt.Color(153, 153, 153));
        txtHra.setText("hora");
        txtHra.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        txtHra.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                txtHraMouseClicked(evt);
            }
        });
        jPanel1.add(txtHra, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 200, 50, 40));

        txtFieldId.setFont(new java.awt.Font("Trebuchet MS", 0, 12)); // NOI18N
        txtFieldId.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jPanel1.add(txtFieldId, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 320, 200, -1));

        txtId.setEditable(false);
        txtId.setBackground(new java.awt.Color(212, 221, 252));
        txtId.setFont(new java.awt.Font("Trebuchet MS", 0, 12)); // NOI18N
        txtId.setForeground(new java.awt.Color(153, 153, 153));
        txtId.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtId.setText("ID");
        txtId.setBorder(null);
        jPanel1.add(txtId, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 300, 40, -1));

        comboBoxHra.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16" }));
        comboBoxHra.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                comboBoxHraActionPerformed(evt);
            }
        });
        jPanel1.add(comboBoxHra, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 240, -1, -1));

        comboBoxMin.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31", "32", "33", "34", "35", "36", "37", "38", "39", "40", "41", "42", "43", "44", "45", "46", "47", "48", "49", "50", "51", "52", "53", "54", "55", "56", "57", "58", "59" }));
        jPanel1.add(comboBoxMin, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 240, -1, -1));

        btnMarcar.setFont(new java.awt.Font("Trebuchet MS", 0, 14)); // NOI18N
        btnMarcar.setText("Marcar");
        btnMarcar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnMarcarActionPerformed(evt);
            }
        });
        jPanel1.add(btnMarcar, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 370, -1, -1));

        lblBordeMarcar.setBackground(new java.awt.Color(153, 153, 153));
        lblBordeMarcar.setForeground(new java.awt.Color(153, 153, 153));
        lblBordeMarcar.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(102, 102, 102), 2));
        jPanel1.add(lblBordeMarcar, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 120, 260, 290));

        jScrollPaneAsis.setBackground(new java.awt.Color(212, 221, 252));

        tableAsis.setBackground(new java.awt.Color(212, 221, 252));
        tableAsis.setForeground(new java.awt.Color(0, 0, 0));
        tableAsis.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {},
            new String [] {
                "ID", "FECHA", "HORA"
            }
        ));
        /*
        tableAsis.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "Fecha", "Hora"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        */
        tableAsis.setEnabled(false);
        tableAsis.setShowHorizontalLines(true);
        tableAsis.setShowVerticalLines(true);
        jScrollPaneAsis.setViewportView(tableAsis);

        jPanel1.add(jScrollPaneAsis, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 120, 410, 300));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/fondo2.jpg"))); // NOI18N
        jLabel1.setText("jLabel1");
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 840, 80));
        jPanel1.add(dateChooser, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 180, 200, 22));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 840, 470));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void lblGrupoMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblGrupoMouseClicked
    }//GEN-LAST:event_lblGrupoMouseClicked

    private void txtFechaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtFechaMouseClicked
    }//GEN-LAST:event_txtFechaMouseClicked

    private void txtMinMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtMinMouseClicked
    }//GEN-LAST:event_txtMinMouseClicked

    private void txtHraMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtHraMouseClicked
    }//GEN-LAST:event_txtHraMouseClicked

    private void comboBoxHraActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_comboBoxHraActionPerformed
    }//GEN-LAST:event_comboBoxHraActionPerformed

    private void btnMarcarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnMarcarActionPerformed
        Date fechaAsis = dateChooser.getDate();
        if (fechaAsis == null) {
            JOptionPane.showMessageDialog(null, "Por favor, selecciona una fecha válida");
            return; 
        }
        String txtId = txtFieldId.getText();
        if (txtId.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Ingrese un ID válido");
            return;
        }
        int ide;
        try {
            ide = Integer.parseInt(txtId);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "El ID debe ser un número entero");
            return;
        }
        String hra = (String) comboBoxHra.getSelectedItem();
        String min = (String) comboBoxMin.getSelectedItem();
        if (hra.isEmpty() || min.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Seleccione una hora y minutos válidos");
            return;
        }
        String hora = hra + ":" + min;
        Asistencia.marcarAsistencia(ide, fechaAsis, hora, tableAsis);

    }//GEN-LAST:event_btnMarcarActionPerformed

    private void btnHomeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnHomeActionPerformed
        dispose();
    }//GEN-LAST:event_btnHomeActionPerformed

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(MarcarA.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(MarcarA.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(MarcarA.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(MarcarA.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new MarcarA().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnHome;
    private javax.swing.JButton btnMarcar;
    private javax.swing.JComboBox<String> comboBoxHra;
    private javax.swing.JComboBox<String> comboBoxMin;
    private com.toedter.calendar.JDateChooser dateChooser;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPaneAsis;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JLabel lblBordeMarcar;
    private javax.swing.JLabel lblGrupo;
    private javax.swing.JTable tableAsis;
    private javax.swing.JLabel txtFecha;
    private javax.swing.JTextField txtFieldId;
    private javax.swing.JLabel txtHra;
    private javax.swing.JTextField txtId;
    private javax.swing.JLabel txtMin;
    // End of variables declaration//GEN-END:variables
}
