/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package FrmBeneficio;

import EDT.Beneficio;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;

/**
 *
 * @author Alexis
 */
public class ConsultarB extends javax.swing.JFrame {

    public ConsultarB() {
        initComponents();
        setIconImage(new ImageIcon(getClass().getResource("/Imagenes/VN.png")).getImage());
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        btnHome7 = new javax.swing.JButton();
        lblGrupo = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        txtId = new javax.swing.JTextField();
        txtId1 = new javax.swing.JTextField();
        txtFieldId = new javax.swing.JTextField();
        comboBoxBene = new javax.swing.JComboBox<>();
        btnBuscar = new javax.swing.JButton();
        lblFondoMedio = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tableBeneficio = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        btnHome7.setBackground(new java.awt.Color(107, 139, 216));
        btnHome7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IconosBtn/volver1.png"))); // NOI18N
        btnHome7.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnHome7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnHome7ActionPerformed(evt);
            }
        });
        getContentPane().add(btnHome7, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 20, 40, 40));

        lblGrupo.setFont(new java.awt.Font("Trebuchet MS", 0, 18)); // NOI18N
        lblGrupo.setForeground(new java.awt.Color(204, 204, 204));
        lblGrupo.setText("Beneficio > Consultar beneficio");
        lblGrupo.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        lblGrupo.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblGrupoMouseClicked(evt);
            }
        });
        getContentPane().add(lblGrupo, new org.netbeans.lib.awtextra.AbsoluteConstraints(580, 40, 260, 40));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/fondo2.jpg"))); // NOI18N
        jLabel1.setText("jLabel1");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 840, 80));

        jPanel1.setBackground(new java.awt.Color(212, 221, 252));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        txtId.setEditable(false);
        txtId.setBackground(new java.awt.Color(212, 221, 252));
        txtId.setFont(new java.awt.Font("Trebuchet MS", 0, 12)); // NOI18N
        txtId.setForeground(new java.awt.Color(153, 153, 153));
        txtId.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtId.setText("ID");
        txtId.setBorder(null);
        jPanel1.add(txtId, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 170, 20, -1));

        txtId1.setEditable(false);
        txtId1.setBackground(new java.awt.Color(212, 221, 252));
        txtId1.setFont(new java.awt.Font("Trebuchet MS", 0, 12)); // NOI18N
        txtId1.setForeground(new java.awt.Color(153, 153, 153));
        txtId1.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtId1.setText("Beneficio");
        txtId1.setBorder(null);
        jPanel1.add(txtId1, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 240, 60, -1));

        txtFieldId.setFont(new java.awt.Font("Trebuchet MS", 0, 12)); // NOI18N
        txtFieldId.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtFieldId.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtFieldIdActionPerformed(evt);
            }
        });
        jPanel1.add(txtFieldId, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 190, 210, -1));

        comboBoxBene.setFont(new java.awt.Font("Trebuchet MS", 0, 12)); // NOI18N
        comboBoxBene.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Ninguno", "Comida", "Transporte", "Formación", "Seguro Médico", "Seguro de Vida", "Seguro de Accidentes", "Talleres" }));
        jPanel1.add(comboBoxBene, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 270, 170, -1));

        btnBuscar.setFont(new java.awt.Font("Trebuchet MS", 0, 12)); // NOI18N
        btnBuscar.setText("Filtrar");
        btnBuscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBuscarActionPerformed(evt);
            }
        });
        jPanel1.add(btnBuscar, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 320, -1, -1));

        lblFondoMedio.setBackground(new java.awt.Color(153, 102, 255));
        lblFondoMedio.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(204, 153, 255), 3, true));
        jPanel1.add(lblFondoMedio, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 140, 270, 240));

        jScrollPane1.setBackground(new java.awt.Color(212, 221, 252));
        jScrollPane1.setForeground(new java.awt.Color(153, 153, 153));
        jScrollPane1.setEnabled(false);
        jScrollPane1.setFont(new java.awt.Font("Trebuchet MS", 0, 12)); // NOI18N
        jScrollPane1.setOpaque(true);

        tableBeneficio.setBackground(new java.awt.Color(212, 221, 252));
        tableBeneficio.setFont(new java.awt.Font("Trebuchet MS", 0, 12)); // NOI18N
        tableBeneficio.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "CI", "Beneficio"
            }
        ));
        tableBeneficio.setEnabled(false);
        tableBeneficio.setShowHorizontalLines(true);
        tableBeneficio.setShowVerticalLines(true);
        jScrollPane1.setViewportView(tableBeneficio);

        jPanel1.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 140, 360, 240));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 840, 470));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void lblGrupoMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblGrupoMouseClicked
    }//GEN-LAST:event_lblGrupoMouseClicked

    private void txtFieldIdActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtFieldIdActionPerformed
    }//GEN-LAST:event_txtFieldIdActionPerformed

    private void btnBuscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBuscarActionPerformed
        String idText = txtFieldId.getText();
        String benex = (String) comboBoxBene.getSelectedItem();

        if (idText.isEmpty() && (benex == null || benex.isEmpty())) {
            JOptionPane.showMessageDialog(this, "Ambos campos estan vacios.", "Error de entrada", JOptionPane.ERROR_MESSAGE);
        }
        try {
            int idx = idText.isEmpty() ? 0 : Integer.parseInt(idText);

            if (idx == 0 && (benex == null || benex.isEmpty())) {
                JOptionPane.showMessageDialog(this, "Ingrese al menos uno de los campos.", "Error de entrada", JOptionPane.ERROR_MESSAGE);
                return;
            }
            Beneficio.consultarBeneficioEmp(idx, benex, tableBeneficio);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Ingrese un ID válido (número entero).", "Error de entrada", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_btnBuscarActionPerformed

    private void btnHome7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnHome7ActionPerformed
        dispose();
    }//GEN-LAST:event_btnHome7ActionPerformed

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(ConsultarB.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(ConsultarB.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(ConsultarB.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ConsultarB.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ConsultarB().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnBuscar;
    private javax.swing.JButton btnHome7;
    private javax.swing.JComboBox<String> comboBoxBene;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lblFondoMedio;
    private javax.swing.JLabel lblGrupo;
    private javax.swing.JTable tableBeneficio;
    private javax.swing.JTextField txtFieldId;
    private javax.swing.JTextField txtId;
    private javax.swing.JTextField txtId1;
    // End of variables declaration//GEN-END:variables
}
