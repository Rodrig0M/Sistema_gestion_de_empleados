/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package FrmRegistro;

import EDT.NodoEmp;
import static Principal.FrmPrincipal.listaEmp;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;

/**
 *
 * @author Alexis
 */
public class BuscarR extends javax.swing.JFrame {

    /**
     * Creates new form Buscar
     */
    public BuscarR() {
        initComponents();
        setIconImage(new ImageIcon(getClass().getResource("/Imagenes/VN.png")).getImage());
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        btnHome7 = new javax.swing.JButton();
        lblGrupo = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jSeparator1 = new javax.swing.JSeparator();
        jTabbedPane1 = new javax.swing.JTabbedPane();
        jPanel2 = new javax.swing.JPanel();
        txtId = new javax.swing.JTextField();
        txtFieldId = new javax.swing.JTextField();
        txtFieldCi = new javax.swing.JTextField();
        txtCi = new javax.swing.JTextField();
        btnBuscar = new javax.swing.JButton();
        lblFondoMedio = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        txtFieldCi1 = new javax.swing.JTextField();
        txtFieldId1 = new javax.swing.JTextField();
        txtFieldApe = new javax.swing.JTextField();
        txtFieldNom = new javax.swing.JTextField();
        txtFieldTel = new javax.swing.JTextField();
        txtFieldMail = new javax.swing.JTextField();
        txtFieldSoli = new javax.swing.JTextField();
        txtFieldSalario = new javax.swing.JTextField();
        txtApe = new javax.swing.JTextField();
        txtCi1 = new javax.swing.JTextField();
        txtSalario = new javax.swing.JTextField();
        txtId1 = new javax.swing.JTextField();
        txtNom = new javax.swing.JTextField();
        txtGen = new javax.swing.JTextField();
        txtTel = new javax.swing.JTextField();
        txtMail = new javax.swing.JTextField();
        txtPuesto = new javax.swing.JTextField();
        txtBen = new javax.swing.JTextField();
        txtSoli = new javax.swing.JTextField();
        txtTurno = new javax.swing.JTextField();
        txtFieldPuesto = new javax.swing.JTextField();
        txtFieldGen = new javax.swing.JTextField();
        txtFieldBen = new javax.swing.JTextField();
        txtFieldTurno = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(212, 221, 252));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        btnHome7.setBackground(new java.awt.Color(107, 139, 216));
        btnHome7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IconosBtn/volver1.png"))); // NOI18N
        btnHome7.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnHome7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnHome7ActionPerformed(evt);
            }
        });
        jPanel1.add(btnHome7, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 20, 40, 40));

        lblGrupo.setFont(new java.awt.Font("Trebuchet MS", 0, 18)); // NOI18N
        lblGrupo.setForeground(new java.awt.Color(204, 204, 204));
        lblGrupo.setText("Registro > Buscar empleado");
        lblGrupo.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        lblGrupo.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblGrupoMouseClicked(evt);
            }
        });
        jPanel1.add(lblGrupo, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 40, 220, 40));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/fondo2.jpg"))); // NOI18N
        jLabel1.setText("jLabel1");
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 840, 80));

        jSeparator1.setBackground(new java.awt.Color(153, 153, 153));
        jSeparator1.setForeground(new java.awt.Color(153, 153, 153));
        jSeparator1.setOpaque(true);
        jPanel1.add(jSeparator1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 80, 840, -1));

        jTabbedPane1.setBackground(new java.awt.Color(102, 102, 102));

        jPanel2.setBackground(new java.awt.Color(212, 221, 252));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        txtId.setEditable(false);
        txtId.setBackground(new java.awt.Color(212, 221, 252));
        txtId.setFont(new java.awt.Font("Trebuchet MS", 0, 12)); // NOI18N
        txtId.setForeground(new java.awt.Color(153, 153, 153));
        txtId.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtId.setText("ID");
        txtId.setBorder(null);
        jPanel2.add(txtId, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 90, 40, -1));

        txtFieldId.setFont(new java.awt.Font("Trebuchet MS", 0, 12)); // NOI18N
        txtFieldId.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jPanel2.add(txtFieldId, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 110, 190, -1));

        txtFieldCi.setFont(new java.awt.Font("Trebuchet MS", 0, 12)); // NOI18N
        txtFieldCi.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jPanel2.add(txtFieldCi, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 180, 190, -1));

        txtCi.setEditable(false);
        txtCi.setBackground(new java.awt.Color(212, 221, 252));
        txtCi.setFont(new java.awt.Font("Trebuchet MS", 0, 12)); // NOI18N
        txtCi.setForeground(new java.awt.Color(153, 153, 153));
        txtCi.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtCi.setText("CI");
        txtCi.setBorder(null);
        jPanel2.add(txtCi, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 160, 40, -1));

        btnBuscar.setFont(new java.awt.Font("Trebuchet MS", 0, 14)); // NOI18N
        btnBuscar.setText("Buscar");
        btnBuscar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnBuscar.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnBuscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBuscarActionPerformed(evt);
            }
        });
        jPanel2.add(btnBuscar, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 240, -1, -1));

        lblFondoMedio.setBackground(new java.awt.Color(153, 102, 255));
        lblFondoMedio.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(204, 153, 255), 3, true));
        jPanel2.add(lblFondoMedio, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 50, 270, 240));

        jTabbedPane1.addTab("tab1", jPanel2);

        jPanel3.setBackground(new java.awt.Color(255, 255, 255));
        jPanel3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        txtFieldCi1.setEditable(false);
        txtFieldCi1.setFont(new java.awt.Font("Trebuchet MS", 0, 12)); // NOI18N
        txtFieldCi1.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtFieldCi1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtFieldCi1ActionPerformed(evt);
            }
        });
        jPanel3.add(txtFieldCi1, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 250, 190, -1));

        txtFieldId1.setEditable(false);
        txtFieldId1.setFont(new java.awt.Font("Trebuchet MS", 0, 12)); // NOI18N
        txtFieldId1.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtFieldId1.setSelectionColor(new java.awt.Color(255, 255, 255));
        jPanel3.add(txtFieldId1, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 70, 190, -1));

        txtFieldApe.setEditable(false);
        txtFieldApe.setFont(new java.awt.Font("Trebuchet MS", 0, 12)); // NOI18N
        txtFieldApe.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jPanel3.add(txtFieldApe, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 190, 190, -1));

        txtFieldNom.setEditable(false);
        txtFieldNom.setFont(new java.awt.Font("Trebuchet MS", 0, 12)); // NOI18N
        txtFieldNom.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtFieldNom.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtFieldNomActionPerformed(evt);
            }
        });
        jPanel3.add(txtFieldNom, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 130, 190, -1));

        txtFieldTel.setEditable(false);
        txtFieldTel.setFont(new java.awt.Font("Trebuchet MS", 0, 12)); // NOI18N
        txtFieldTel.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jPanel3.add(txtFieldTel, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 130, 190, -1));

        txtFieldMail.setEditable(false);
        txtFieldMail.setFont(new java.awt.Font("Trebuchet MS", 0, 12)); // NOI18N
        txtFieldMail.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jPanel3.add(txtFieldMail, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 190, 190, -1));

        txtFieldSoli.setEditable(false);
        txtFieldSoli.setFont(new java.awt.Font("Trebuchet MS", 0, 12)); // NOI18N
        txtFieldSoli.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jPanel3.add(txtFieldSoli, new org.netbeans.lib.awtextra.AbsoluteConstraints(580, 130, 190, -1));

        txtFieldSalario.setEditable(false);
        txtFieldSalario.setFont(new java.awt.Font("Trebuchet MS", 0, 12)); // NOI18N
        txtFieldSalario.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jPanel3.add(txtFieldSalario, new org.netbeans.lib.awtextra.AbsoluteConstraints(580, 250, 190, -1));

        txtApe.setEditable(false);
        txtApe.setBackground(new java.awt.Color(255, 255, 255));
        txtApe.setFont(new java.awt.Font("Trebuchet MS", 0, 12)); // NOI18N
        txtApe.setForeground(new java.awt.Color(153, 153, 153));
        txtApe.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtApe.setText("Apellido");
        txtApe.setBorder(null);
        txtApe.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtApeActionPerformed(evt);
            }
        });
        jPanel3.add(txtApe, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 170, 60, -1));

        txtCi1.setEditable(false);
        txtCi1.setBackground(new java.awt.Color(255, 255, 255));
        txtCi1.setFont(new java.awt.Font("Trebuchet MS", 0, 12)); // NOI18N
        txtCi1.setForeground(new java.awt.Color(153, 153, 153));
        txtCi1.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtCi1.setText("CI");
        txtCi1.setBorder(null);
        jPanel3.add(txtCi1, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 230, 40, -1));

        txtSalario.setEditable(false);
        txtSalario.setBackground(new java.awt.Color(255, 255, 255));
        txtSalario.setFont(new java.awt.Font("Trebuchet MS", 0, 12)); // NOI18N
        txtSalario.setForeground(new java.awt.Color(153, 153, 153));
        txtSalario.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtSalario.setText("Salario");
        txtSalario.setBorder(null);
        txtSalario.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtSalarioActionPerformed(evt);
            }
        });
        jPanel3.add(txtSalario, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 230, 60, -1));

        txtId1.setEditable(false);
        txtId1.setBackground(new java.awt.Color(255, 255, 255));
        txtId1.setFont(new java.awt.Font("Trebuchet MS", 0, 12)); // NOI18N
        txtId1.setForeground(new java.awt.Color(153, 153, 153));
        txtId1.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtId1.setText("ID");
        txtId1.setBorder(null);
        jPanel3.add(txtId1, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 50, 40, -1));

        txtNom.setEditable(false);
        txtNom.setBackground(new java.awt.Color(255, 255, 255));
        txtNom.setFont(new java.awt.Font("Trebuchet MS", 0, 12)); // NOI18N
        txtNom.setForeground(new java.awt.Color(153, 153, 153));
        txtNom.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtNom.setText("Nombre");
        txtNom.setBorder(null);
        txtNom.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtNomActionPerformed(evt);
            }
        });
        jPanel3.add(txtNom, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 110, 60, -1));

        txtGen.setEditable(false);
        txtGen.setBackground(new java.awt.Color(255, 255, 255));
        txtGen.setFont(new java.awt.Font("Trebuchet MS", 0, 12)); // NOI18N
        txtGen.setForeground(new java.awt.Color(153, 153, 153));
        txtGen.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtGen.setText("Género");
        txtGen.setBorder(null);
        txtGen.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtGenActionPerformed(evt);
            }
        });
        jPanel3.add(txtGen, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 50, 60, -1));

        txtTel.setEditable(false);
        txtTel.setBackground(new java.awt.Color(255, 255, 255));
        txtTel.setFont(new java.awt.Font("Trebuchet MS", 0, 12)); // NOI18N
        txtTel.setForeground(new java.awt.Color(153, 153, 153));
        txtTel.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtTel.setText("Teléfono");
        txtTel.setBorder(null);
        txtTel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtTelActionPerformed(evt);
            }
        });
        jPanel3.add(txtTel, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 110, 60, -1));

        txtMail.setEditable(false);
        txtMail.setBackground(new java.awt.Color(255, 255, 255));
        txtMail.setFont(new java.awt.Font("Trebuchet MS", 0, 12)); // NOI18N
        txtMail.setForeground(new java.awt.Color(153, 153, 153));
        txtMail.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtMail.setText("Correo");
        txtMail.setBorder(null);
        txtMail.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtMailActionPerformed(evt);
            }
        });
        jPanel3.add(txtMail, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 170, 60, -1));

        txtPuesto.setEditable(false);
        txtPuesto.setBackground(new java.awt.Color(255, 255, 255));
        txtPuesto.setFont(new java.awt.Font("Trebuchet MS", 0, 12)); // NOI18N
        txtPuesto.setForeground(new java.awt.Color(153, 153, 153));
        txtPuesto.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtPuesto.setText("Puesto");
        txtPuesto.setBorder(null);
        txtPuesto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtPuestoActionPerformed(evt);
            }
        });
        jPanel3.add(txtPuesto, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 230, 60, -1));

        txtBen.setEditable(false);
        txtBen.setBackground(new java.awt.Color(255, 255, 255));
        txtBen.setFont(new java.awt.Font("Trebuchet MS", 0, 12)); // NOI18N
        txtBen.setForeground(new java.awt.Color(153, 153, 153));
        txtBen.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtBen.setText("Beneficio");
        txtBen.setBorder(null);
        txtBen.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtBenActionPerformed(evt);
            }
        });
        jPanel3.add(txtBen, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 50, 60, -1));

        txtSoli.setEditable(false);
        txtSoli.setBackground(new java.awt.Color(255, 255, 255));
        txtSoli.setFont(new java.awt.Font("Trebuchet MS", 0, 12)); // NOI18N
        txtSoli.setForeground(new java.awt.Color(153, 153, 153));
        txtSoli.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtSoli.setText("Solicitud");
        txtSoli.setBorder(null);
        txtSoli.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtSoliActionPerformed(evt);
            }
        });
        jPanel3.add(txtSoli, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 110, 60, -1));

        txtTurno.setEditable(false);
        txtTurno.setBackground(new java.awt.Color(255, 255, 255));
        txtTurno.setFont(new java.awt.Font("Trebuchet MS", 0, 12)); // NOI18N
        txtTurno.setForeground(new java.awt.Color(153, 153, 153));
        txtTurno.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtTurno.setText("Turno");
        txtTurno.setBorder(null);
        txtTurno.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtTurnoActionPerformed(evt);
            }
        });
        jPanel3.add(txtTurno, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 170, 60, -1));

        txtFieldPuesto.setEditable(false);
        txtFieldPuesto.setFont(new java.awt.Font("Trebuchet MS", 0, 12)); // NOI18N
        txtFieldPuesto.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtFieldPuesto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtFieldPuestoActionPerformed(evt);
            }
        });
        jPanel3.add(txtFieldPuesto, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 250, 190, -1));

        txtFieldGen.setEditable(false);
        txtFieldGen.setFont(new java.awt.Font("Trebuchet MS", 0, 12)); // NOI18N
        txtFieldGen.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtFieldGen.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtFieldGenActionPerformed(evt);
            }
        });
        jPanel3.add(txtFieldGen, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 70, 190, -1));

        txtFieldBen.setEditable(false);
        txtFieldBen.setFont(new java.awt.Font("Trebuchet MS", 0, 12)); // NOI18N
        txtFieldBen.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtFieldBen.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtFieldBenActionPerformed(evt);
            }
        });
        jPanel3.add(txtFieldBen, new org.netbeans.lib.awtextra.AbsoluteConstraints(580, 70, 190, -1));

        txtFieldTurno.setEditable(false);
        txtFieldTurno.setFont(new java.awt.Font("Trebuchet MS", 0, 12)); // NOI18N
        txtFieldTurno.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jPanel3.add(txtFieldTurno, new org.netbeans.lib.awtextra.AbsoluteConstraints(580, 190, 190, -1));

        jTabbedPane1.addTab("tab2", jPanel3);

        jPanel1.add(jTabbedPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 40, 820, 420));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 840, 470));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void lblGrupoMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblGrupoMouseClicked
        //        System.exit(0);
    }//GEN-LAST:event_lblGrupoMouseClicked

    private void btnBuscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBuscarActionPerformed
        try {
            int ide = 0;
            int ced = 0;

            if (!txtFieldId.getText().isEmpty()) {
                ide = Integer.parseInt(txtFieldId.getText().trim());
            } else if (!txtFieldCi.getText().isEmpty()) {
                ced = Integer.parseInt(txtFieldCi.getText().trim());
            } else {
                JOptionPane.showMessageDialog(this, "Ingrese al menos un valor.", "Error de entrada", JOptionPane.ERROR_MESSAGE);
                return;
            }
            NodoEmp R = listaEmp.getP();
            while (R != null) {
                if ((ide != 0 && R.getQ().getId() == ide) || (ced != 0 && R.getQ().getCi() == ced)) {
                    //JOptionPane.showMessageDialog(null, "Se encontró el empleado");
                    jTabbedPane1.setSelectedIndex(1);
                    txtFieldId1.setText(String.valueOf(R.getQ().getId()));
                    txtFieldNom.setText(R.getQ().getNom());
                    txtFieldApe.setText(R.getQ().getApe());
                    txtFieldCi1.setText(String.valueOf(R.getQ().getCi()));
                    txtFieldGen.setText(R.getQ().getGen());
                    txtFieldTel.setText(String.valueOf(R.getQ().getTel()));
                    txtFieldMail.setText(R.getQ().getMail());
                    txtFieldPuesto.setText(R.getQ().getPuesto());
                    txtFieldBen.setText(R.getQ().getBeneficio());
                    txtFieldSoli.setText(R.getQ().getSoli());
                    txtFieldTurno.setText(R.getQ().getTurno());
                    txtFieldSalario.setText(String.valueOf(R.getQ().getSueldo()));
                    return;
                }   
                R = R.getSig();
            }
            JOptionPane.showMessageDialog(this, "No se encontro un empleado con el ID y CI ingresados.", "Error", JOptionPane.ERROR_MESSAGE);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Ingrese valores validos (números enteros).", "Error de entrada", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_btnBuscarActionPerformed

    private void txtFieldCi1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtFieldCi1ActionPerformed
    }//GEN-LAST:event_txtFieldCi1ActionPerformed

    private void txtFieldNomActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtFieldNomActionPerformed
    }//GEN-LAST:event_txtFieldNomActionPerformed

    private void txtApeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtApeActionPerformed
    }//GEN-LAST:event_txtApeActionPerformed

    private void txtSalarioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtSalarioActionPerformed
    }//GEN-LAST:event_txtSalarioActionPerformed

    private void txtNomActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtNomActionPerformed
    }//GEN-LAST:event_txtNomActionPerformed

    private void txtGenActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtGenActionPerformed
    }//GEN-LAST:event_txtGenActionPerformed

    private void txtTelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtTelActionPerformed
    }//GEN-LAST:event_txtTelActionPerformed

    private void txtMailActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtMailActionPerformed
    }//GEN-LAST:event_txtMailActionPerformed

    private void txtPuestoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtPuestoActionPerformed
    }//GEN-LAST:event_txtPuestoActionPerformed

    private void txtBenActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtBenActionPerformed
    }//GEN-LAST:event_txtBenActionPerformed

    private void txtSoliActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtSoliActionPerformed
    }//GEN-LAST:event_txtSoliActionPerformed

    private void txtTurnoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtTurnoActionPerformed
    }//GEN-LAST:event_txtTurnoActionPerformed

    private void txtFieldPuestoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtFieldPuestoActionPerformed
    }//GEN-LAST:event_txtFieldPuestoActionPerformed

    private void txtFieldGenActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtFieldGenActionPerformed
    }//GEN-LAST:event_txtFieldGenActionPerformed

    private void txtFieldBenActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtFieldBenActionPerformed
    }//GEN-LAST:event_txtFieldBenActionPerformed

    private void btnHome7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnHome7ActionPerformed
        dispose();
    }//GEN-LAST:event_btnHome7ActionPerformed

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(BuscarR.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(BuscarR.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(BuscarR.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(BuscarR.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new BuscarR().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnBuscar;
    private javax.swing.JButton btnHome7;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JLabel lblFondoMedio;
    private javax.swing.JLabel lblGrupo;
    private javax.swing.JTextField txtApe;
    private javax.swing.JTextField txtBen;
    private javax.swing.JTextField txtCi;
    private javax.swing.JTextField txtCi1;
    private javax.swing.JTextField txtFieldApe;
    private javax.swing.JTextField txtFieldBen;
    private javax.swing.JTextField txtFieldCi;
    private javax.swing.JTextField txtFieldCi1;
    private javax.swing.JTextField txtFieldGen;
    private javax.swing.JTextField txtFieldId;
    private javax.swing.JTextField txtFieldId1;
    private javax.swing.JTextField txtFieldMail;
    private javax.swing.JTextField txtFieldNom;
    private javax.swing.JTextField txtFieldPuesto;
    private javax.swing.JTextField txtFieldSalario;
    private javax.swing.JTextField txtFieldSoli;
    private javax.swing.JTextField txtFieldTel;
    private javax.swing.JTextField txtFieldTurno;
    private javax.swing.JTextField txtGen;
    private javax.swing.JTextField txtId;
    private javax.swing.JTextField txtId1;
    private javax.swing.JTextField txtMail;
    private javax.swing.JTextField txtNom;
    private javax.swing.JTextField txtPuesto;
    private javax.swing.JTextField txtSalario;
    private javax.swing.JTextField txtSoli;
    private javax.swing.JTextField txtTel;
    private javax.swing.JTextField txtTurno;
    // End of variables declaration//GEN-END:variables
}
