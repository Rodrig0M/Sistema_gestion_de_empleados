/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package FrmRegistro;

import EDT.Empleado;
import EDT.NodoEmp;
import static Principal.FrmPrincipal.listaEmp;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

/**
 *
 * @author Alexis
 */
public class EditarR extends javax.swing.JFrame {

    public EditarR() {
        initComponents();
        setIconImage(new ImageIcon(getClass().getResource("/Imagenes/VN.png")).getImage());
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        Fondo = new javax.swing.JPanel();
        btnHome7 = new javax.swing.JButton();
        jSeparator1 = new javax.swing.JSeparator();
        lblGrupo = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jTabbedPane = new javax.swing.JTabbedPane();
        Pane1 = new javax.swing.JPanel();
        fieldId = new javax.swing.JTextField();
        txtId = new javax.swing.JTextField();
        fieldCi = new javax.swing.JTextField();
        txtCi = new javax.swing.JTextField();
        btnBuscar = new javax.swing.JButton();
        lblFondoMedio = new javax.swing.JLabel();
        Pane2 = new javax.swing.JPanel();
        txtFieldCi1 = new javax.swing.JTextField();
        txtFieldId1 = new javax.swing.JTextField();
        txtFieldApe = new javax.swing.JTextField();
        txtFieldNom = new javax.swing.JTextField();
        txtFieldTel = new javax.swing.JTextField();
        txtFieldMail = new javax.swing.JTextField();
        txtFieldSoli = new javax.swing.JTextField();
        btnGuardar = new javax.swing.JButton();
        comboBoxGen = new javax.swing.JComboBox<>();
        comboBoxPuesto = new javax.swing.JComboBox<>();
        comboBoxBen = new javax.swing.JComboBox<>();
        comboBoxTurno = new javax.swing.JComboBox<>();
        txtApe = new javax.swing.JTextField();
        txtCi1 = new javax.swing.JTextField();
        txtSalario = new javax.swing.JTextField();
        txtId1 = new javax.swing.JTextField();
        txtNom = new javax.swing.JTextField();
        txtGen = new javax.swing.JTextField();
        txtTel = new javax.swing.JTextField();
        txtMail = new javax.swing.JTextField();
        txtPuesto = new javax.swing.JTextField();
        txtBen = new javax.swing.JTextField();
        txtSoli = new javax.swing.JTextField();
        txtTurno = new javax.swing.JTextField();
        SpinnerSalario = new javax.swing.JSpinner();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);

        Fondo.setBackground(new java.awt.Color(212, 221, 252));
        Fondo.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(204, 153, 255), 3));
        Fondo.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        btnHome7.setBackground(new java.awt.Color(107, 139, 216));
        btnHome7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IconosBtn/volver1.png"))); // NOI18N
        btnHome7.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnHome7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnHome7ActionPerformed(evt);
            }
        });
        Fondo.add(btnHome7, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 20, 40, 40));

        jSeparator1.setBackground(new java.awt.Color(153, 153, 153));
        jSeparator1.setForeground(new java.awt.Color(153, 153, 153));
        jSeparator1.setOpaque(true);
        Fondo.add(jSeparator1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 80, 840, -1));

        lblGrupo.setFont(new java.awt.Font("Trebuchet MS", 0, 18)); // NOI18N
        lblGrupo.setForeground(new java.awt.Color(204, 204, 204));
        lblGrupo.setText("Registro > Editar empleado");
        lblGrupo.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        lblGrupo.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblGrupoMouseClicked(evt);
            }
        });
        Fondo.add(lblGrupo, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 30, 220, 40));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/fondo2.jpg"))); // NOI18N
        jLabel1.setText("jLabel1");
        Fondo.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 840, 80));

        jTabbedPane.setBackground(new java.awt.Color(153, 153, 153));

        Pane1.setBackground(new java.awt.Color(212, 221, 252));
        Pane1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        fieldId.setFont(new java.awt.Font("Trebuchet MS", 0, 12)); // NOI18N
        fieldId.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        Pane1.add(fieldId, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 110, 190, -1));

        txtId.setEditable(false);
        txtId.setBackground(new java.awt.Color(212, 221, 252));
        txtId.setFont(new java.awt.Font("Trebuchet MS", 0, 12)); // NOI18N
        txtId.setForeground(new java.awt.Color(153, 153, 153));
        txtId.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtId.setText("ID");
        txtId.setBorder(null);
        Pane1.add(txtId, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 90, 40, -1));

        fieldCi.setFont(new java.awt.Font("Trebuchet MS", 0, 12)); // NOI18N
        fieldCi.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        Pane1.add(fieldCi, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 180, 190, -1));

        txtCi.setEditable(false);
        txtCi.setBackground(new java.awt.Color(212, 221, 252));
        txtCi.setFont(new java.awt.Font("Trebuchet MS", 0, 12)); // NOI18N
        txtCi.setForeground(new java.awt.Color(153, 153, 153));
        txtCi.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtCi.setText("CI");
        txtCi.setBorder(null);
        Pane1.add(txtCi, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 160, 40, -1));

        btnBuscar.setFont(new java.awt.Font("Trebuchet MS", 0, 14)); // NOI18N
        btnBuscar.setText("Buscar");
        btnBuscar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnBuscar.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnBuscar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnBuscarMouseClicked(evt);
            }
        });
        btnBuscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBuscarActionPerformed(evt);
            }
        });
        Pane1.add(btnBuscar, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 240, -1, -1));

        lblFondoMedio.setBackground(new java.awt.Color(153, 102, 255));
        lblFondoMedio.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(204, 153, 255), 3, true));
        Pane1.add(lblFondoMedio, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 60, 270, 240));

        jTabbedPane.addTab("tab1", Pane1);

        Pane2.setBackground(new java.awt.Color(212, 221, 252));
        Pane2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        txtFieldCi1.setFont(new java.awt.Font("Trebuchet MS", 0, 12)); // NOI18N
        txtFieldCi1.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtFieldCi1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtFieldCi1ActionPerformed(evt);
            }
        });
        Pane2.add(txtFieldCi1, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 240, 190, -1));

        txtFieldId1.setFont(new java.awt.Font("Trebuchet MS", 0, 12)); // NOI18N
        txtFieldId1.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        Pane2.add(txtFieldId1, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 60, 190, -1));

        txtFieldApe.setFont(new java.awt.Font("Trebuchet MS", 0, 12)); // NOI18N
        txtFieldApe.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        Pane2.add(txtFieldApe, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 180, 190, -1));

        txtFieldNom.setFont(new java.awt.Font("Trebuchet MS", 0, 12)); // NOI18N
        txtFieldNom.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtFieldNom.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtFieldNomActionPerformed(evt);
            }
        });
        Pane2.add(txtFieldNom, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 120, 190, -1));

        txtFieldTel.setFont(new java.awt.Font("Trebuchet MS", 0, 12)); // NOI18N
        txtFieldTel.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        Pane2.add(txtFieldTel, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 120, 190, -1));

        txtFieldMail.setFont(new java.awt.Font("Trebuchet MS", 0, 12)); // NOI18N
        txtFieldMail.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        Pane2.add(txtFieldMail, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 180, 190, -1));

        txtFieldSoli.setEditable(false);
        txtFieldSoli.setFont(new java.awt.Font("Trebuchet MS", 0, 12)); // NOI18N
        txtFieldSoli.setHorizontalAlignment(javax.swing.JTextField.LEFT);
        txtFieldSoli.setText("Ninguno");
        txtFieldSoli.setEnabled(false);
        Pane2.add(txtFieldSoli, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 120, 190, -1));

        btnGuardar.setFont(new java.awt.Font("Trebuchet MS", 0, 12)); // NOI18N
        btnGuardar.setText("Guardar");
        btnGuardar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btnGuardarMouseEntered(evt);
            }
        });
        btnGuardar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGuardarActionPerformed(evt);
            }
        });
        Pane2.add(btnGuardar, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 300, 90, 30));

        comboBoxGen.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Femenino", "Masculino" }));
        comboBoxGen.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        Pane2.add(comboBoxGen, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 60, 190, -1));

        comboBoxPuesto.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Gerente ", "Asesor", "Etc" }));
        Pane2.add(comboBoxPuesto, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 240, 190, -1));

        comboBoxBen.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Ninguno", "Transporte", "Alimento", "Salud" }));
        comboBoxBen.setEnabled(false);
        Pane2.add(comboBoxBen, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 60, 190, -1));

        comboBoxTurno.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Mañana", "Tarde" }));
        Pane2.add(comboBoxTurno, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 180, 190, -1));

        txtApe.setEditable(false);
        txtApe.setBackground(new java.awt.Color(212, 221, 252));
        txtApe.setFont(new java.awt.Font("Trebuchet MS", 0, 12)); // NOI18N
        txtApe.setForeground(new java.awt.Color(153, 153, 153));
        txtApe.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtApe.setText("Apellido");
        txtApe.setBorder(null);
        txtApe.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtApeActionPerformed(evt);
            }
        });
        Pane2.add(txtApe, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 160, 60, -1));

        txtCi1.setEditable(false);
        txtCi1.setBackground(new java.awt.Color(212, 221, 252));
        txtCi1.setFont(new java.awt.Font("Trebuchet MS", 0, 12)); // NOI18N
        txtCi1.setForeground(new java.awt.Color(153, 153, 153));
        txtCi1.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtCi1.setText("CI");
        txtCi1.setBorder(null);
        Pane2.add(txtCi1, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 220, 40, -1));

        txtSalario.setEditable(false);
        txtSalario.setBackground(new java.awt.Color(212, 221, 252));
        txtSalario.setFont(new java.awt.Font("Trebuchet MS", 0, 12)); // NOI18N
        txtSalario.setForeground(new java.awt.Color(153, 153, 153));
        txtSalario.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtSalario.setText("Salario");
        txtSalario.setBorder(null);
        txtSalario.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtSalarioActionPerformed(evt);
            }
        });
        Pane2.add(txtSalario, new org.netbeans.lib.awtextra.AbsoluteConstraints(660, 220, 60, -1));

        txtId1.setEditable(false);
        txtId1.setBackground(new java.awt.Color(212, 221, 252));
        txtId1.setFont(new java.awt.Font("Trebuchet MS", 0, 12)); // NOI18N
        txtId1.setForeground(new java.awt.Color(153, 153, 153));
        txtId1.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtId1.setText("ID");
        txtId1.setBorder(null);
        Pane2.add(txtId1, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 40, 40, -1));

        txtNom.setEditable(false);
        txtNom.setBackground(new java.awt.Color(212, 221, 252));
        txtNom.setFont(new java.awt.Font("Trebuchet MS", 0, 12)); // NOI18N
        txtNom.setForeground(new java.awt.Color(153, 153, 153));
        txtNom.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtNom.setText("Nombre");
        txtNom.setBorder(null);
        txtNom.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtNomActionPerformed(evt);
            }
        });
        Pane2.add(txtNom, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 100, 60, -1));

        txtGen.setEditable(false);
        txtGen.setBackground(new java.awt.Color(212, 221, 252));
        txtGen.setFont(new java.awt.Font("Trebuchet MS", 0, 12)); // NOI18N
        txtGen.setForeground(new java.awt.Color(153, 153, 153));
        txtGen.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtGen.setText("Género");
        txtGen.setBorder(null);
        txtGen.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtGenActionPerformed(evt);
            }
        });
        Pane2.add(txtGen, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 40, 60, -1));

        txtTel.setEditable(false);
        txtTel.setBackground(new java.awt.Color(212, 221, 252));
        txtTel.setFont(new java.awt.Font("Trebuchet MS", 0, 12)); // NOI18N
        txtTel.setForeground(new java.awt.Color(153, 153, 153));
        txtTel.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtTel.setText("Teléfono");
        txtTel.setBorder(null);
        txtTel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtTelActionPerformed(evt);
            }
        });
        Pane2.add(txtTel, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 100, 60, -1));

        txtMail.setEditable(false);
        txtMail.setBackground(new java.awt.Color(212, 221, 252));
        txtMail.setFont(new java.awt.Font("Trebuchet MS", 0, 12)); // NOI18N
        txtMail.setForeground(new java.awt.Color(153, 153, 153));
        txtMail.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtMail.setText("Correo");
        txtMail.setBorder(null);
        txtMail.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtMailActionPerformed(evt);
            }
        });
        Pane2.add(txtMail, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 160, 60, -1));

        txtPuesto.setEditable(false);
        txtPuesto.setBackground(new java.awt.Color(212, 221, 252));
        txtPuesto.setFont(new java.awt.Font("Trebuchet MS", 0, 12)); // NOI18N
        txtPuesto.setForeground(new java.awt.Color(153, 153, 153));
        txtPuesto.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtPuesto.setText("Puesto");
        txtPuesto.setBorder(null);
        txtPuesto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtPuestoActionPerformed(evt);
            }
        });
        Pane2.add(txtPuesto, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 220, 60, -1));

        txtBen.setEditable(false);
        txtBen.setBackground(new java.awt.Color(212, 221, 252));
        txtBen.setFont(new java.awt.Font("Trebuchet MS", 0, 12)); // NOI18N
        txtBen.setForeground(new java.awt.Color(153, 153, 153));
        txtBen.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtBen.setText("Beneficio");
        txtBen.setBorder(null);
        txtBen.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtBenActionPerformed(evt);
            }
        });
        Pane2.add(txtBen, new org.netbeans.lib.awtextra.AbsoluteConstraints(660, 40, 60, -1));

        txtSoli.setEditable(false);
        txtSoli.setBackground(new java.awt.Color(212, 221, 252));
        txtSoli.setFont(new java.awt.Font("Trebuchet MS", 0, 12)); // NOI18N
        txtSoli.setForeground(new java.awt.Color(153, 153, 153));
        txtSoli.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtSoli.setText("Solicitud");
        txtSoli.setBorder(null);
        txtSoli.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtSoliActionPerformed(evt);
            }
        });
        Pane2.add(txtSoli, new org.netbeans.lib.awtextra.AbsoluteConstraints(660, 100, 60, -1));

        txtTurno.setEditable(false);
        txtTurno.setBackground(new java.awt.Color(212, 221, 252));
        txtTurno.setFont(new java.awt.Font("Trebuchet MS", 0, 12)); // NOI18N
        txtTurno.setForeground(new java.awt.Color(153, 153, 153));
        txtTurno.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtTurno.setText("Turno");
        txtTurno.setBorder(null);
        txtTurno.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtTurnoActionPerformed(evt);
            }
        });
        Pane2.add(txtTurno, new org.netbeans.lib.awtextra.AbsoluteConstraints(660, 160, 60, -1));
        Pane2.add(SpinnerSalario, new org.netbeans.lib.awtextra.AbsoluteConstraints(640, 240, 100, -1));

        jTabbedPane.addTab("tab2", Pane2);

        Fondo.add(jTabbedPane, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 40, 840, 420));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(Fondo, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(Fondo, javax.swing.GroupLayout.DEFAULT_SIZE, 470, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void lblGrupoMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblGrupoMouseClicked
        //        System.exit(0);
    }//GEN-LAST:event_lblGrupoMouseClicked

    private void txtTurnoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtTurnoActionPerformed
    }//GEN-LAST:event_txtTurnoActionPerformed

    private void txtSoliActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtSoliActionPerformed
    }//GEN-LAST:event_txtSoliActionPerformed

    private void txtBenActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtBenActionPerformed
    }//GEN-LAST:event_txtBenActionPerformed

    private void txtPuestoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtPuestoActionPerformed
    }//GEN-LAST:event_txtPuestoActionPerformed

    private void txtMailActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtMailActionPerformed
    }//GEN-LAST:event_txtMailActionPerformed

    private void txtTelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtTelActionPerformed
    }//GEN-LAST:event_txtTelActionPerformed

    private void txtGenActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtGenActionPerformed
    }//GEN-LAST:event_txtGenActionPerformed

    private void txtNomActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtNomActionPerformed
    }//GEN-LAST:event_txtNomActionPerformed

    private void txtSalarioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtSalarioActionPerformed
    }//GEN-LAST:event_txtSalarioActionPerformed

    private void txtApeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtApeActionPerformed
    }//GEN-LAST:event_txtApeActionPerformed

    
    private void btnGuardarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGuardarActionPerformed
    }//GEN-LAST:event_btnGuardarActionPerformed
    
    private void btnGuardarMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnGuardarMouseEntered
    }//GEN-LAST:event_btnGuardarMouseEntered

    private void txtFieldNomActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtFieldNomActionPerformed
    }//GEN-LAST:event_txtFieldNomActionPerformed

    private void txtFieldCi1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtFieldCi1ActionPerformed
    }//GEN-LAST:event_txtFieldCi1ActionPerformed

    private void btnBuscarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnBuscarMouseClicked
    }//GEN-LAST:event_btnBuscarMouseClicked

    private void btnBuscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBuscarActionPerformed
        NodoEmp R = listaEmp.getP();
        try {
            int ide = 0;
            int ced = 0;

            if (!fieldId.getText().isEmpty()) {
                ide = Integer.parseInt(fieldId.getText().trim());
            } else if (!fieldCi.getText().isEmpty()) {
                ced = Integer.parseInt(fieldCi.getText().trim());
            } else {
                JOptionPane.showMessageDialog(this, "Ingrese al menos un dato.", "Error de entrada", JOptionPane.ERROR_MESSAGE);
                return;
            }
            while (R != null) {
                if ((ide != 0 && R.getQ().getId() == ide) || (ced != 0 && R.getQ().getCi() == ced)) {
                    Empleado x = R.getQ();
                    jTabbedPane.setSelectedIndex(1);
                    txtFieldId1.setText(String.valueOf(R.getQ().getId()));
                    txtFieldNom.setText(R.getQ().getNom());
                    txtFieldApe.setText(R.getQ().getApe());
                    txtFieldCi1.setText(String.valueOf(R.getQ().getCi()));
                    comboBoxGen.setSelectedItem(R.getQ().getGen());
                    txtFieldTel.setText(String.valueOf(R.getQ().getTel()));
                    txtFieldMail.setText(R.getQ().getMail());
                    comboBoxPuesto.setSelectedItem(R.getQ().getPuesto());
                    comboBoxBen.setSelectedItem(R.getQ().getBeneficio());
                    txtFieldSoli.setText(R.getQ().getSoli());
                    comboBoxTurno.setSelectedItem(R.getQ().getTurno());
                    SpinnerSalario.setValue(R.getQ().getSueldo());
                    btnGuardar.addActionListener(new ActionListener() {
                    @Override
                        public void actionPerformed(ActionEvent e) {
                            editarEmp(x);
                        }
                    });
                    return;
                }   
                R = R.getSig();
            }
            JOptionPane.showMessageDialog(this, "No se encontro un empleado con ID o CI ingresados.", "Error", JOptionPane.ERROR_MESSAGE);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Ingrese valores válidos (números enteros).", "Error de entrada", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_btnBuscarActionPerformed

    private void btnHome7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnHome7ActionPerformed
        dispose();
    }//GEN-LAST:event_btnHome7ActionPerformed
    private void editarEmp(Empleado x){
        x.setId(Integer.parseInt(txtFieldId1.getText()));
        x.setNom(txtFieldNom.getText());
        x.setApe(txtFieldApe.getText());
        x.setCi(Integer.parseInt(txtFieldCi1.getText()));
        x.setGen((String) comboBoxGen.getSelectedItem());
        x.setTel(Integer.parseInt(txtFieldTel.getText()));
        x.setMail(txtFieldMail.getText());
        x.setPuesto((String) comboBoxPuesto.getSelectedItem());
        x.setBeneficio((String) comboBoxBen.getSelectedItem());
        x.setSoli(txtFieldSoli.getText());
        x.setTurno((String) comboBoxTurno.getSelectedItem());
        
        //BUG => SI NO SE MODIFICA EL VALOR DEL SPINNER NO SE GUARDAN LOS DATOS EDITADOS
        //x.setSueldo((int) SpinnerSalario.getValue());
        SpinnerSalario.addChangeListener(new ChangeListener() {
        @Override
            public void stateChanged(ChangeEvent e) {
            // Actualiza el valor del salario en el objeto Empleado
            x.setSueldo((int) SpinnerSalario.getValue());
            }
        });
        JOptionPane.showMessageDialog(null, "Datos actualizados correctamente");
    }    
    
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(EditarR.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(EditarR.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(EditarR.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(EditarR.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new EditarR().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel Fondo;
    private javax.swing.JPanel Pane1;
    private javax.swing.JPanel Pane2;
    private javax.swing.JSpinner SpinnerSalario;
    private javax.swing.JButton btnBuscar;
    private javax.swing.JButton btnGuardar;
    private javax.swing.JButton btnHome7;
    private javax.swing.JComboBox<String> comboBoxBen;
    private javax.swing.JComboBox<String> comboBoxGen;
    private javax.swing.JComboBox<String> comboBoxPuesto;
    private javax.swing.JComboBox<String> comboBoxTurno;
    private javax.swing.JTextField fieldCi;
    private javax.swing.JTextField fieldId;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JTabbedPane jTabbedPane;
    private javax.swing.JLabel lblFondoMedio;
    private javax.swing.JLabel lblGrupo;
    private javax.swing.JTextField txtApe;
    private javax.swing.JTextField txtBen;
    private javax.swing.JTextField txtCi;
    private javax.swing.JTextField txtCi1;
    private javax.swing.JTextField txtFieldApe;
    private javax.swing.JTextField txtFieldCi1;
    private javax.swing.JTextField txtFieldId1;
    private javax.swing.JTextField txtFieldMail;
    private javax.swing.JTextField txtFieldNom;
    private javax.swing.JTextField txtFieldSoli;
    private javax.swing.JTextField txtFieldTel;
    private javax.swing.JTextField txtGen;
    private javax.swing.JTextField txtId;
    private javax.swing.JTextField txtId1;
    private javax.swing.JTextField txtMail;
    private javax.swing.JTextField txtNom;
    private javax.swing.JTextField txtPuesto;
    private javax.swing.JTextField txtSalario;
    private javax.swing.JTextField txtSoli;
    private javax.swing.JTextField txtTel;
    private javax.swing.JTextField txtTurno;
    // End of variables declaration//GEN-END:variables


}