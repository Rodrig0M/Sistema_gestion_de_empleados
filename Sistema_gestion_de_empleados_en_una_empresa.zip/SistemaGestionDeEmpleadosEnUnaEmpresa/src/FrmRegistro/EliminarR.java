/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package FrmRegistro;

import EDT.NodoEmp;
import static Principal.FrmPrincipal.listaEmp;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;

/**
 *
 * @author Alexis
 */
public class EliminarR extends javax.swing.JFrame {

    public EliminarR() {
        initComponents();
        setIconImage(new ImageIcon(getClass().getResource("/Imagenes/VN.png")).getImage());
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        txtId = new javax.swing.JTextField();
        txtFieldId = new javax.swing.JTextField();
        txtFieldCi = new javax.swing.JTextField();
        txtCi = new javax.swing.JTextField();
        btnEliminar = new javax.swing.JButton();
        lblFondoMedio = new javax.swing.JLabel();
        lblGrupo = new javax.swing.JLabel();
        jSeparator1 = new javax.swing.JSeparator();
        btnHome7 = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setBackground(new java.awt.Color(255, 255, 255));
        setUndecorated(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(212, 221, 252));
        jPanel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(204, 153, 255), 3));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        txtId.setEditable(false);
        txtId.setBackground(new java.awt.Color(212, 221, 252));
        txtId.setFont(new java.awt.Font("Trebuchet MS", 0, 12)); // NOI18N
        txtId.setForeground(new java.awt.Color(153, 153, 153));
        txtId.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtId.setText("ID");
        txtId.setBorder(null);
        jPanel1.add(txtId, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 180, 40, -1));

        txtFieldId.setFont(new java.awt.Font("Trebuchet MS", 0, 12)); // NOI18N
        txtFieldId.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jPanel1.add(txtFieldId, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 200, 190, -1));

        txtFieldCi.setFont(new java.awt.Font("Trebuchet MS", 0, 12)); // NOI18N
        txtFieldCi.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtFieldCi.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtFieldCiActionPerformed(evt);
            }
        });
        jPanel1.add(txtFieldCi, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 270, 190, -1));

        txtCi.setEditable(false);
        txtCi.setBackground(new java.awt.Color(212, 221, 252));
        txtCi.setFont(new java.awt.Font("Trebuchet MS", 0, 12)); // NOI18N
        txtCi.setForeground(new java.awt.Color(153, 153, 153));
        txtCi.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtCi.setText("CI");
        txtCi.setBorder(null);
        jPanel1.add(txtCi, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 250, 40, -1));

        btnEliminar.setFont(new java.awt.Font("Trebuchet MS", 0, 14)); // NOI18N
        btnEliminar.setText("Eliminar");
        btnEliminar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnEliminar.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnEliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEliminarActionPerformed(evt);
            }
        });
        jPanel1.add(btnEliminar, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 330, -1, -1));

        lblFondoMedio.setBackground(new java.awt.Color(153, 102, 255));
        lblFondoMedio.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(204, 153, 255), 3, true));
        jPanel1.add(lblFondoMedio, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 140, 270, 240));

        lblGrupo.setFont(new java.awt.Font("Trebuchet MS", 0, 18)); // NOI18N
        lblGrupo.setForeground(new java.awt.Color(204, 204, 204));
        lblGrupo.setText("Registro > Eliminar empleado");
        lblGrupo.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        lblGrupo.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblGrupoMouseClicked(evt);
            }
        });
        jPanel1.add(lblGrupo, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 40, 240, 40));

        jSeparator1.setBackground(new java.awt.Color(153, 153, 153));
        jSeparator1.setForeground(new java.awt.Color(153, 153, 153));
        jSeparator1.setOpaque(true);
        jPanel1.add(jSeparator1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 80, 840, -1));

        btnHome7.setBackground(new java.awt.Color(107, 139, 216));
        btnHome7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IconosBtn/volver1.png"))); // NOI18N
        btnHome7.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnHome7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnHome7ActionPerformed(evt);
            }
        });
        jPanel1.add(btnHome7, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 20, 40, 40));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/fondo2.jpg"))); // NOI18N
        jLabel1.setText("jLabel1");
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 840, 80));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 840, 470));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void lblGrupoMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblGrupoMouseClicked
    }//GEN-LAST:event_lblGrupoMouseClicked

    private void txtFieldCiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtFieldCiActionPerformed
    }//GEN-LAST:event_txtFieldCiActionPerformed

    private void btnEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEliminarActionPerformed
        try {
            int ide = 0;
            int ced = 0;
            if (!txtFieldId.getText().isEmpty()) {
                ide = Integer.parseInt(txtFieldId.getText().trim());
            } else if (!txtFieldCi.getText().isEmpty()) {
                ced = Integer.parseInt(txtFieldCi.getText().trim());
            } else {
                JOptionPane.showMessageDialog(this, "Ingrese al menos un dato.", "Error de entrada", JOptionPane.ERROR_MESSAGE);
                return;
            }
            NodoEmp R = listaEmp.getP();
            NodoEmp anterior = null;
            while (R != null) {
                if ((ide != 0 && R.getQ().getId() == ide) || (ced != 0 && R.getQ().getCi() == ced)) {
                    if (anterior == null) {
                        listaEmp.setP(R.getSig());
                    } else {
                    anterior.setSig(R.getSig());
                    }
                    JOptionPane.showMessageDialog(this, "Empleado eliminado correctamente.", "Información", JOptionPane.INFORMATION_MESSAGE);
                    return;
                }
                anterior = R;
                R = R.getSig();
            }
            JOptionPane.showMessageDialog(this, "No se encontro un empleado con ID o CI ingresados.", "Error", JOptionPane.ERROR_MESSAGE);

        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Ingrese valores válidos (números enteros).", "Error de entrada", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_btnEliminarActionPerformed

    private void btnHome7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnHome7ActionPerformed
        dispose();
    }//GEN-LAST:event_btnHome7ActionPerformed

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(EliminarR.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(EliminarR.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(EliminarR.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(EliminarR.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new EliminarR().setVisible(true);
            }
        });
    }

    
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnEliminar;
    private javax.swing.JButton btnHome7;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JLabel lblFondoMedio;
    private javax.swing.JLabel lblGrupo;
    private javax.swing.JTextField txtCi;
    private javax.swing.JTextField txtFieldCi;
    private javax.swing.JTextField txtFieldId;
    private javax.swing.JTextField txtId;
    // End of variables declaration//GEN-END:variables
}
