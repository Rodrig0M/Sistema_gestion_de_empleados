/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package FrmRegistro;

import EDT.Empleado;
import static Principal.FrmPrincipal.listaEmp;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;


/**
 *
 * @author Alexis
 */
public class AgregarR extends javax.swing.JFrame {
    
    public AgregarR() {

        initComponents();
        setIconImage(new ImageIcon(getClass().getResource("/Imagenes/VN.png")).getImage());
        this.setLocationRelativeTo(null);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        lblGrupo = new javax.swing.JLabel();
        jSeparator1 = new javax.swing.JSeparator();
        txtFieldCi = new javax.swing.JTextField();
        txtFieldId = new javax.swing.JTextField();
        txtFieldApe = new javax.swing.JTextField();
        txtFieldNom = new javax.swing.JTextField();
        txtFieldTel = new javax.swing.JTextField();
        txtFieldMail = new javax.swing.JTextField();
        txtFieldSoli = new javax.swing.JTextField();
        btnAgregar = new javax.swing.JButton();
        btnLimpiar = new javax.swing.JButton();
        comboBoxGen = new javax.swing.JComboBox<>();
        comboBoxPuesto = new javax.swing.JComboBox<>();
        comboBoxBen = new javax.swing.JComboBox<>();
        comboBoxTurno = new javax.swing.JComboBox<>();
        txtApe = new javax.swing.JTextField();
        txtCi = new javax.swing.JTextField();
        txtSalario = new javax.swing.JTextField();
        txtId = new javax.swing.JTextField();
        txtNom = new javax.swing.JTextField();
        txtGen = new javax.swing.JTextField();
        txtTel = new javax.swing.JTextField();
        txtMail = new javax.swing.JTextField();
        txtPuesto = new javax.swing.JTextField();
        txtBen = new javax.swing.JTextField();
        txtSoli = new javax.swing.JTextField();
        txtTurno = new javax.swing.JTextField();
        SpinnerSalario = new javax.swing.JSpinner();
        btnHome7 = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(255, 255, 255));
        setUndecorated(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(234, 255, 240));
        jPanel1.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(204, 153, 255), 3, true));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        lblGrupo.setFont(new java.awt.Font("Trebuchet MS", 0, 18)); // NOI18N
        lblGrupo.setForeground(new java.awt.Color(204, 204, 204));
        lblGrupo.setText("Registro > Agregar empleados");
        lblGrupo.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        lblGrupo.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblGrupoMouseClicked(evt);
            }
        });
        jPanel1.add(lblGrupo, new org.netbeans.lib.awtextra.AbsoluteConstraints(580, 40, 250, 40));

        jSeparator1.setBackground(new java.awt.Color(153, 153, 153));
        jSeparator1.setForeground(new java.awt.Color(153, 153, 153));
        jSeparator1.setOpaque(true);
        jPanel1.add(jSeparator1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 80, 840, -1));

        txtFieldCi.setFont(new java.awt.Font("Trebuchet MS", 0, 12)); // NOI18N
        txtFieldCi.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtFieldCi.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtFieldCiActionPerformed(evt);
            }
        });
        jPanel1.add(txtFieldCi, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 320, 190, -1));

        txtFieldId.setFont(new java.awt.Font("Trebuchet MS", 0, 12)); // NOI18N
        txtFieldId.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jPanel1.add(txtFieldId, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 140, 190, -1));

        txtFieldApe.setFont(new java.awt.Font("Trebuchet MS", 0, 12)); // NOI18N
        txtFieldApe.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jPanel1.add(txtFieldApe, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 260, 190, -1));

        txtFieldNom.setFont(new java.awt.Font("Trebuchet MS", 0, 12)); // NOI18N
        txtFieldNom.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtFieldNom.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtFieldNomActionPerformed(evt);
            }
        });
        jPanel1.add(txtFieldNom, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 200, 190, -1));

        txtFieldTel.setFont(new java.awt.Font("Trebuchet MS", 0, 12)); // NOI18N
        txtFieldTel.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jPanel1.add(txtFieldTel, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 200, 190, -1));

        txtFieldMail.setFont(new java.awt.Font("Trebuchet MS", 0, 12)); // NOI18N
        txtFieldMail.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jPanel1.add(txtFieldMail, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 260, 190, -1));

        txtFieldSoli.setEditable(false);
        txtFieldSoli.setFont(new java.awt.Font("Trebuchet MS", 0, 12)); // NOI18N
        txtFieldSoli.setHorizontalAlignment(javax.swing.JTextField.LEFT);
        txtFieldSoli.setText("Ninguno");
        txtFieldSoli.setEnabled(false);
        jPanel1.add(txtFieldSoli, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 200, 190, -1));

        btnAgregar.setText("Agregar");
        btnAgregar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btnAgregarMouseEntered(evt);
            }
        });
        btnAgregar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAgregarActionPerformed(evt);
            }
        });
        jPanel1.add(btnAgregar, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 390, -1, -1));

        btnLimpiar.setText("Limpiar");
        btnLimpiar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLimpiarActionPerformed(evt);
            }
        });
        jPanel1.add(btnLimpiar, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 390, -1, -1));

        comboBoxGen.setFont(new java.awt.Font("Trebuchet MS", 0, 12)); // NOI18N
        comboBoxGen.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Femenino", "Masculino" }));
        comboBoxGen.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jPanel1.add(comboBoxGen, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 140, 190, -1));

        comboBoxPuesto.setFont(new java.awt.Font("Trebuchet MS", 0, 12)); // NOI18N
        comboBoxPuesto.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Gerente ", "Director", "Asesor", "Economista", "Comprador", "Ejecutivo", "RRHH", "Analista", "Supervisor", "Marketing", "Comunicación" }));
        jPanel1.add(comboBoxPuesto, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 320, 190, -1));

        comboBoxBen.setFont(new java.awt.Font("Trebuchet MS", 0, 12)); // NOI18N
        comboBoxBen.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Ninguno", "Transporte", "Alimento", "Salud" }));
        comboBoxBen.setEnabled(false);
        jPanel1.add(comboBoxBen, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 140, 190, -1));

        comboBoxTurno.setFont(new java.awt.Font("Trebuchet MS", 0, 12)); // NOI18N
        comboBoxTurno.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Mañana", "Tarde" }));
        jPanel1.add(comboBoxTurno, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 260, 190, -1));

        txtApe.setEditable(false);
        txtApe.setBackground(new java.awt.Color(212, 221, 252));
        txtApe.setFont(new java.awt.Font("Trebuchet MS", 0, 12)); // NOI18N
        txtApe.setForeground(new java.awt.Color(153, 153, 153));
        txtApe.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtApe.setText("Apellido");
        txtApe.setBorder(null);
        txtApe.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtApeActionPerformed(evt);
            }
        });
        jPanel1.add(txtApe, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 240, 60, -1));

        txtCi.setEditable(false);
        txtCi.setBackground(new java.awt.Color(212, 221, 252));
        txtCi.setFont(new java.awt.Font("Trebuchet MS", 0, 12)); // NOI18N
        txtCi.setForeground(new java.awt.Color(153, 153, 153));
        txtCi.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtCi.setText("CI");
        txtCi.setBorder(null);
        jPanel1.add(txtCi, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 300, 40, -1));

        txtSalario.setEditable(false);
        txtSalario.setBackground(new java.awt.Color(212, 221, 252));
        txtSalario.setFont(new java.awt.Font("Trebuchet MS", 0, 12)); // NOI18N
        txtSalario.setForeground(new java.awt.Color(153, 153, 153));
        txtSalario.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtSalario.setText("Salario");
        txtSalario.setBorder(null);
        txtSalario.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtSalarioActionPerformed(evt);
            }
        });
        jPanel1.add(txtSalario, new org.netbeans.lib.awtextra.AbsoluteConstraints(660, 300, 60, -1));

        txtId.setEditable(false);
        txtId.setBackground(new java.awt.Color(212, 221, 252));
        txtId.setFont(new java.awt.Font("Trebuchet MS", 0, 12)); // NOI18N
        txtId.setForeground(new java.awt.Color(153, 153, 153));
        txtId.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtId.setText("ID");
        txtId.setBorder(null);
        jPanel1.add(txtId, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 120, 40, -1));

        txtNom.setEditable(false);
        txtNom.setBackground(new java.awt.Color(212, 221, 252));
        txtNom.setFont(new java.awt.Font("Trebuchet MS", 0, 12)); // NOI18N
        txtNom.setForeground(new java.awt.Color(153, 153, 153));
        txtNom.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtNom.setText("Nombre");
        txtNom.setBorder(null);
        txtNom.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtNomActionPerformed(evt);
            }
        });
        jPanel1.add(txtNom, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 180, 60, -1));

        txtGen.setEditable(false);
        txtGen.setBackground(new java.awt.Color(212, 221, 252));
        txtGen.setFont(new java.awt.Font("Trebuchet MS", 0, 12)); // NOI18N
        txtGen.setForeground(new java.awt.Color(153, 153, 153));
        txtGen.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtGen.setText("Género");
        txtGen.setBorder(null);
        txtGen.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtGenActionPerformed(evt);
            }
        });
        jPanel1.add(txtGen, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 120, 60, -1));

        txtTel.setEditable(false);
        txtTel.setBackground(new java.awt.Color(212, 221, 252));
        txtTel.setFont(new java.awt.Font("Trebuchet MS", 0, 12)); // NOI18N
        txtTel.setForeground(new java.awt.Color(153, 153, 153));
        txtTel.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtTel.setText("Teléfono");
        txtTel.setBorder(null);
        txtTel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtTelActionPerformed(evt);
            }
        });
        jPanel1.add(txtTel, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 180, 60, -1));

        txtMail.setEditable(false);
        txtMail.setBackground(new java.awt.Color(212, 221, 252));
        txtMail.setFont(new java.awt.Font("Trebuchet MS", 0, 12)); // NOI18N
        txtMail.setForeground(new java.awt.Color(153, 153, 153));
        txtMail.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtMail.setText("Correo");
        txtMail.setBorder(null);
        txtMail.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtMailActionPerformed(evt);
            }
        });
        jPanel1.add(txtMail, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 240, 60, -1));

        txtPuesto.setEditable(false);
        txtPuesto.setBackground(new java.awt.Color(212, 221, 252));
        txtPuesto.setFont(new java.awt.Font("Trebuchet MS", 0, 12)); // NOI18N
        txtPuesto.setForeground(new java.awt.Color(153, 153, 153));
        txtPuesto.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtPuesto.setText("Puesto");
        txtPuesto.setBorder(null);
        txtPuesto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtPuestoActionPerformed(evt);
            }
        });
        jPanel1.add(txtPuesto, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 300, 60, -1));

        txtBen.setEditable(false);
        txtBen.setBackground(new java.awt.Color(212, 221, 252));
        txtBen.setFont(new java.awt.Font("Trebuchet MS", 0, 12)); // NOI18N
        txtBen.setForeground(new java.awt.Color(153, 153, 153));
        txtBen.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtBen.setText("Beneficio");
        txtBen.setBorder(null);
        txtBen.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtBenActionPerformed(evt);
            }
        });
        jPanel1.add(txtBen, new org.netbeans.lib.awtextra.AbsoluteConstraints(660, 120, 60, -1));

        txtSoli.setEditable(false);
        txtSoli.setBackground(new java.awt.Color(212, 221, 252));
        txtSoli.setFont(new java.awt.Font("Trebuchet MS", 0, 12)); // NOI18N
        txtSoli.setForeground(new java.awt.Color(153, 153, 153));
        txtSoli.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtSoli.setText("Solicitud");
        txtSoli.setBorder(null);
        txtSoli.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtSoliActionPerformed(evt);
            }
        });
        jPanel1.add(txtSoli, new org.netbeans.lib.awtextra.AbsoluteConstraints(660, 180, 60, -1));

        txtTurno.setEditable(false);
        txtTurno.setBackground(new java.awt.Color(212, 221, 252));
        txtTurno.setFont(new java.awt.Font("Trebuchet MS", 0, 12)); // NOI18N
        txtTurno.setForeground(new java.awt.Color(153, 153, 153));
        txtTurno.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtTurno.setText("Turno");
        txtTurno.setBorder(null);
        txtTurno.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtTurnoActionPerformed(evt);
            }
        });
        jPanel1.add(txtTurno, new org.netbeans.lib.awtextra.AbsoluteConstraints(660, 240, 60, -1));
        jPanel1.add(SpinnerSalario, new org.netbeans.lib.awtextra.AbsoluteConstraints(640, 320, 100, -1));

        btnHome7.setBackground(new java.awt.Color(107, 139, 216));
        btnHome7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IconosBtn/volver1.png"))); // NOI18N
        btnHome7.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnHome7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnHome7ActionPerformed(evt);
            }
        });
        jPanel1.add(btnHome7, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 20, 40, 40));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/fondo2.jpg"))); // NOI18N
        jLabel1.setText("jLabel1");
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 840, 80));

        jLabel2.setBackground(new java.awt.Color(212, 221, 252));
        jLabel2.setOpaque(true);
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 80, 840, 400));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 840, 480));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void lblGrupoMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblGrupoMouseClicked
        //        System.exit(0);
    }//GEN-LAST:event_lblGrupoMouseClicked

    private void txtFieldCiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtFieldCiActionPerformed
    }//GEN-LAST:event_txtFieldCiActionPerformed

    private void txtFieldNomActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtFieldNomActionPerformed
    }//GEN-LAST:event_txtFieldNomActionPerformed

    private void btnAgregarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAgregarActionPerformed
        if (txtFieldId.getText().isEmpty() || txtFieldNom.getText().isEmpty() || txtFieldApe.getText().isEmpty()|| txtFieldCi.getText().isEmpty() || txtFieldTel.getText().isEmpty() || txtFieldMail.getText().isEmpty()|| txtFieldSoli.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Por favor, complete todos los campos.", "Error", JOptionPane.ERROR_MESSAGE);
            return; 
        }
        try {
            int id = Integer.parseInt(txtFieldId.getText());
            int ci = Integer.parseInt(txtFieldCi.getText());
            int tel = Integer.parseInt(txtFieldTel.getText());
            int sueldo = (int) SpinnerSalario.getValue();
            String nom = txtFieldNom.getText().trim();
            String ape = txtFieldApe.getText().trim();
            String gen = (String) comboBoxGen.getSelectedItem();
            String mail = txtFieldMail.getText().trim();
            String puesto = (String) comboBoxPuesto.getSelectedItem();
            String ben = (String) comboBoxBen.getSelectedItem();
            String soli = txtFieldSoli.getText().trim();
            String turno = (String) comboBoxTurno.getSelectedItem();
            EDT.Empleado.agregarEmp(id, nom, ape, ci, gen, tel, mail, puesto, ben, soli, turno, sueldo);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Ingrese valores numéricos válidos en los campos correspondientes.", "Error", JOptionPane.ERROR_MESSAGE);
        }
//  SIN VALIDACION DE DATOS 
//            int id = Integer.parseInt(txtFieldId.getText());
//            String nom = txtFieldNom.getText();
//            String ape = txtFieldApe.getText();
//            int ci = Integer.parseInt(txtFieldCi.getText());
//            String gen = (String)comboBoxGen.getSelectedItem();
//            int tel = Integer.parseInt(txtFieldTel.getText());
//            String mail = txtFieldMail.getText();
//            String puesto = (String)comboBoxPuesto.getSelectedItem();
//            String ben = (String)comboBoxBen.getSelectedItem();
//            String soli = txtFieldSoli.getText();
//            String turno = (String)comboBoxTurno.getSelectedItem();
//            int sueldo = (int) SpinnerSalario.getValue();
//            EDT.Empleado.agregarEmp(id, nom, ape, ci, gen, tel, mail, puesto, ben, soli, turno, sueldo);
    }//GEN-LAST:event_btnAgregarActionPerformed

    private void txtApeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtApeActionPerformed
    }//GEN-LAST:event_txtApeActionPerformed

    private void txtSalarioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtSalarioActionPerformed
    }//GEN-LAST:event_txtSalarioActionPerformed

    private void txtNomActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtNomActionPerformed
    }//GEN-LAST:event_txtNomActionPerformed

    private void txtGenActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtGenActionPerformed
    }//GEN-LAST:event_txtGenActionPerformed

    private void txtTelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtTelActionPerformed
    }//GEN-LAST:event_txtTelActionPerformed

    private void txtMailActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtMailActionPerformed
    }//GEN-LAST:event_txtMailActionPerformed

    private void txtPuestoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtPuestoActionPerformed
    }//GEN-LAST:event_txtPuestoActionPerformed

    private void txtBenActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtBenActionPerformed
    }//GEN-LAST:event_txtBenActionPerformed

    private void txtSoliActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtSoliActionPerformed
    }//GEN-LAST:event_txtSoliActionPerformed

    private void txtTurnoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtTurnoActionPerformed
    }//GEN-LAST:event_txtTurnoActionPerformed

    private void btnAgregarMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnAgregarMouseEntered
        
    }//GEN-LAST:event_btnAgregarMouseEntered

    private void btnLimpiarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLimpiarActionPerformed
        txtFieldId.setText("");
        txtFieldNom.setText("");
        txtFieldApe.setText("");
        txtFieldCi.setText("");
        txtFieldTel.setText("");
        txtFieldMail.setText("");
        txtFieldSoli.setText("");
        SpinnerSalario.setValue(0);
    }//GEN-LAST:event_btnLimpiarActionPerformed

    private void btnHome7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnHome7ActionPerformed
        dispose();
    }//GEN-LAST:event_btnHome7ActionPerformed

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(AgregarR.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(AgregarR.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(AgregarR.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(AgregarR.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new AgregarR().setVisible(true);
            }
        });
    }

   
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JSpinner SpinnerSalario;
    private javax.swing.JButton btnAgregar;
    private javax.swing.JButton btnHome7;
    private javax.swing.JButton btnLimpiar;
    private javax.swing.JComboBox<String> comboBoxBen;
    private javax.swing.JComboBox<String> comboBoxGen;
    private javax.swing.JComboBox<String> comboBoxPuesto;
    private javax.swing.JComboBox<String> comboBoxTurno;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JLabel lblGrupo;
    private javax.swing.JTextField txtApe;
    private javax.swing.JTextField txtBen;
    private javax.swing.JTextField txtCi;
    private javax.swing.JTextField txtFieldApe;
    private javax.swing.JTextField txtFieldCi;
    private javax.swing.JTextField txtFieldId;
    private javax.swing.JTextField txtFieldMail;
    private javax.swing.JTextField txtFieldNom;
    private javax.swing.JTextField txtFieldSoli;
    private javax.swing.JTextField txtFieldTel;
    private javax.swing.JTextField txtGen;
    private javax.swing.JTextField txtId;
    private javax.swing.JTextField txtMail;
    private javax.swing.JTextField txtNom;
    private javax.swing.JTextField txtPuesto;
    private javax.swing.JTextField txtSalario;
    private javax.swing.JTextField txtSoli;
    private javax.swing.JTextField txtTel;
    private javax.swing.JTextField txtTurno;
    // End of variables declaration//GEN-END:variables
}
