/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package FrmSolicitud;

import EDT.Solicitud;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.ImageIcon;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPopupMenu;
import javax.swing.JTable;
import javax.swing.SwingUtilities;

/**
 *
 * @author Alexis
 */
public class AdministrarS extends javax.swing.JFrame {

    public AdministrarS() {
        initComponents();
        setIconImage(new ImageIcon(getClass().getResource("/Imagenes/VN.png")).getImage());
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        popUpMenu = new javax.swing.JPopupMenu();
        jMenuItem1 = new javax.swing.JMenuItem();
        jMenuItem2 = new javax.swing.JMenuItem();
        btnHome7 = new javax.swing.JButton();
        lblGrupo = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        txtId = new javax.swing.JTextField();
        txtFieldId = new javax.swing.JTextField();
        btnFiltrar = new javax.swing.JButton();
        txtSoli = new javax.swing.JTextField();
        comboBoxSoli = new javax.swing.JComboBox<>();
        lblFondoMedio = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        tableSoli = new javax.swing.JTable();

        jMenuItem1.setText("Aceptar solicitud");
        jMenuItem1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jMenuItem1MouseClicked(evt);
            }
        });
        jMenuItem1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem1ActionPerformed(evt);
            }
        });
        popUpMenu.add(jMenuItem1);

        jMenuItem2.setText("Rechazar solicitud");
        jMenuItem2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jMenuItem2MouseClicked(evt);
            }
        });
        popUpMenu.add(jMenuItem2);

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        btnHome7.setBackground(new java.awt.Color(107, 139, 216));
        btnHome7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IconosBtn/volver1.png"))); // NOI18N
        btnHome7.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnHome7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnHome7ActionPerformed(evt);
            }
        });
        getContentPane().add(btnHome7, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 20, 40, 40));

        lblGrupo.setFont(new java.awt.Font("Trebuchet MS", 0, 18)); // NOI18N
        lblGrupo.setForeground(new java.awt.Color(204, 204, 204));
        lblGrupo.setText("Solicitud > Administrar solicitud");
        lblGrupo.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        lblGrupo.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblGrupoMouseClicked(evt);
            }
        });
        getContentPane().add(lblGrupo, new org.netbeans.lib.awtextra.AbsoluteConstraints(570, 40, 260, 40));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/fondo2.jpg"))); // NOI18N
        jLabel1.setText("jLabel1");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 840, 80));

        jPanel1.setBackground(new java.awt.Color(212, 221, 252));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        txtId.setEditable(false);
        txtId.setBackground(new java.awt.Color(212, 221, 252));
        txtId.setFont(new java.awt.Font("Trebuchet MS", 0, 12)); // NOI18N
        txtId.setForeground(new java.awt.Color(153, 153, 153));
        txtId.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtId.setText("ID");
        txtId.setBorder(null);
        jPanel1.add(txtId, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 170, 60, -1));

        txtFieldId.setFont(new java.awt.Font("Trebuchet MS", 0, 12)); // NOI18N
        txtFieldId.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jPanel1.add(txtFieldId, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 200, 190, -1));

        btnFiltrar.setFont(new java.awt.Font("Trebuchet MS", 0, 14)); // NOI18N
        btnFiltrar.setText("Filtrar");
        btnFiltrar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnFiltrar.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnFiltrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnFiltrarActionPerformed(evt);
            }
        });
        jPanel1.add(btnFiltrar, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 330, -1, -1));

        txtSoli.setEditable(false);
        txtSoli.setBackground(new java.awt.Color(212, 221, 252));
        txtSoli.setFont(new java.awt.Font("Trebuchet MS", 0, 12)); // NOI18N
        txtSoli.setForeground(new java.awt.Color(153, 153, 153));
        txtSoli.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtSoli.setText("Solicitud");
        txtSoli.setBorder(null);
        jPanel1.add(txtSoli, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 240, 60, -1));

        comboBoxSoli.setFont(new java.awt.Font("Trebuchet MS", 0, 14)); // NOI18N
        comboBoxSoli.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Ninguno", "Todos", "Vacaciones", "Licencia por enfermedad", "Permiso", "Home office", "Cambio de turno", "Recursos", "Ascenso", "Cambio de puesto", "Reembolso de gastos" }));
        jPanel1.add(comboBoxSoli, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 270, 190, -1));

        lblFondoMedio.setBackground(new java.awt.Color(153, 102, 255));
        lblFondoMedio.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(204, 153, 255), 3, true));
        jPanel1.add(lblFondoMedio, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 140, 270, 240));

        jScrollPane2.setBackground(new java.awt.Color(212, 221, 252));
        jScrollPane2.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_ALWAYS);
        jScrollPane2.setVerticalScrollBarPolicy(javax.swing.ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
        jScrollPane2.setFont(new java.awt.Font("Trebuchet MS", 0, 12)); // NOI18N

        tableSoli.setAutoCreateRowSorter(true);
        tableSoli.setBackground(new java.awt.Color(212, 221, 252));
        tableSoli.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "Nombre", "Apellido", "Solicitud", "Estado"
            }
        ));
        for (int i = 0; i < tableSoli.getColumnCount(); i++) {
            tableSoli.getColumnModel().getColumn(i).setPreferredWidth(300); // Ajusta el ancho según tus necesidades
        }

        // Establecer el modo de redimensionamiento automático para ajustar el ancho automáticamente
        tableSoli.setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);
        tableSoli.setShowHorizontalLines(true);
        tableSoli.setShowVerticalLines(true);
        tableSoli.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tableSoliMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(tableSoli);

        jPanel1.add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 140, 400, 240));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 840, 470));

        pack();
    }// </editor-fold>//GEN-END:initComponents
    
    private void tableSoliMouseClicked(java.awt.event.MouseEvent evt) {
        if (SwingUtilities.isRightMouseButton(evt)) {
            int row = tableSoli.rowAtPoint(evt.getPoint());
            int column = tableSoli.columnAtPoint(evt.getPoint());

            if (row >= 0 && column >= 0) {
                tableSoli.setRowSelectionInterval(row, row);
                tableSoli.setColumnSelectionInterval(column, column);
                
                Object id = tableSoli.getValueAt(row, 0);
                Object tipoSoli = tableSoli.getValueAt(row, 3);
                Object estado = tableSoli.getValueAt(row, 4);
                
                JPopupMenu popupMenu = new JPopupMenu();
                JMenuItem acceptItem = new JMenuItem("Aceptar Solicitud");
                JMenuItem rejectItem = new JMenuItem("Rechazar Solicitud");

                popupMenu.add(acceptItem);
                popupMenu.add(rejectItem);

                acceptItem.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        tableSoli.setValueAt("Aceptada", row, 4);
                        Solicitud.aceptarSoli(id, tipoSoli, "Aceptada");
                        
                        //ELIMINAR DIRECTAMENTE LA FILA 
                        //DefaultTableModel model = (DefaultTableModel) tableSoli.getModel();
                        //model.removeRow(row);
                        
                        Solicitud.eliminarSoli(id);
                    }
                });
                rejectItem.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        tableSoli.setValueAt("Rechazada", row, 4);
                        Solicitud.rechazarSoli(id, "Rechazada");
                        
                        //ELIMINAR DIRECTAMENTE LA FILA 
                        //DefaultTableModel model = (DefaultTableModel) tableSoli.getModel();
                        //model.removeRow(row);
                        
                        Solicitud.eliminarSoli(id);
                    }
                });

                popupMenu.show(tableSoli, evt.getX(), evt.getY());
            }
        }
    }
    private void lblGrupoMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblGrupoMouseClicked
    }//GEN-LAST:event_lblGrupoMouseClicked

    private void btnFiltrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnFiltrarActionPerformed
        String idText = txtFieldId.getText();
        String solix = (String) comboBoxSoli.getSelectedItem();
        
        if (idText.isEmpty() && (solix == null || solix.isEmpty())) {
            JOptionPane.showMessageDialog(null, "Ambos campos están vacíos");
            return;
        }   

        try {
            int idx = 0;

            if (!idText.isEmpty()) {
                idx = Integer.parseInt(idText);
            }

            if (idx == 0 && (solix == null || solix.isEmpty())) {
                JOptionPane.showMessageDialog(null, "Ingrese al menos uno de los campos.");
                return;
            }

            Solicitud.administrarSolicitud(idx, solix, tableSoli);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Ingrese un valor válido para el ID.");
        }

    }//GEN-LAST:event_btnFiltrarActionPerformed
/*
    private void tableSoliMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tableSoliMouseClicked
    }//GEN-LAST:event_tableSoliMouseClicked
*/
  
    private void jMenuItem1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jMenuItem1MouseClicked
        JOptionPane.showMessageDialog(null, "Funcionando");
    }//GEN-LAST:event_jMenuItem1MouseClicked

    private void jMenuItem1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem1ActionPerformed
    }//GEN-LAST:event_jMenuItem1ActionPerformed

    private void jMenuItem2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jMenuItem2MouseClicked
    }//GEN-LAST:event_jMenuItem2MouseClicked

    private void btnHome7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnHome7ActionPerformed
        dispose();
    }//GEN-LAST:event_btnHome7ActionPerformed
   
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(AdministrarS.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(AdministrarS.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(AdministrarS.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(AdministrarS.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new AdministrarS().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnFiltrar;
    private javax.swing.JButton btnHome7;
    private javax.swing.JComboBox<String> comboBoxSoli;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JMenuItem jMenuItem1;
    private javax.swing.JMenuItem jMenuItem2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JLabel lblFondoMedio;
    private javax.swing.JLabel lblGrupo;
    private javax.swing.JPopupMenu popUpMenu;
    private javax.swing.JTable tableSoli;
    private javax.swing.JTextField txtFieldId;
    private javax.swing.JTextField txtId;
    private javax.swing.JTextField txtSoli;
    // End of variables declaration//GEN-END:variables
}
